
namespace TestStringDictionaryHelper
{
    using CSHARP.V8.Helpers.TextString;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;
    using System.Collections.Generic;

    [TestClass]
    public class TestDictionaryStringHelper
    {
        /// <summary>
        /// Test getting email addresses from test string
        /// </summary>
        [TestMethod]
        public void Test_001_001_DictionaryToDelimitedString()
        {

            string LABEL_ID_IMPORTANT = "Label_5899897717973802285";
            string LABEL_ID_FOR_DEE_DEE = "Label_9033317630670315605";
            string LABEL_ID_INDEED = "Label_879641434133708990";
            string LABEL_ID_CAREERS = "Label_7773108088391662111";

            var rules = new Dictionary<string, string>()
            {
                // Careers 
                ["FROM~CONTAINS~careers@"] = LABEL_ID_CAREERS + "|INBOX",

                // Indeed
                ["FROM~CONTAINS~@indeed.com"] = LABEL_ID_CAREERS + "|INBOX",


                // These are the important rules
                ["FROM~CONTAINS~@startmeupniagara.ca"] = LABEL_ID_IMPORTANT + "|",
                ["FROM~CONTAINS~@ontario.ca"] = LABEL_ID_IMPORTANT + "|",
                ["FROM~CONTAINS~@ontario.ca"] = LABEL_ID_IMPORTANT + "|",
                ["FROM~CONTAINS~@niagararegion.ca"] = LABEL_ID_IMPORTANT + "|",


                // These are the Dee Dee rules
                ["FROM~CONTAINS~deals@"] = LABEL_ID_FOR_DEE_DEE + "|INBOX",
                ["FROM~CONTAINS~e-feedback@"] = LABEL_ID_FOR_DEE_DEE + "|INBOX",
                ["FROM~CONTAINS~enews@"] = LABEL_ID_FOR_DEE_DEE + "|INBOX",
                ["FROM~CONTAINS~hello@"] = LABEL_ID_FOR_DEE_DEE + "|INBOX",
                ["FROM~CONTAINS~info@"] = LABEL_ID_FOR_DEE_DEE + "|INBOX",
                ["FROM~CONTAINS~marketing@"] = LABEL_ID_FOR_DEE_DEE + "|INBOX",
                ["FROM~CONTAINS~newsletter@"] = LABEL_ID_FOR_DEE_DEE + "|INBOX",
                ["FROM~CONTAINS~newsletters@"] = LABEL_ID_FOR_DEE_DEE + "|INBOX",
                ["FROM~CONTAINS~noreply"] = LABEL_ID_FOR_DEE_DEE + "|INBOX",
                ["FROM~CONTAINS~no-reply@"] = LABEL_ID_FOR_DEE_DEE + "|INBOX",
                ["FROM~CONTAINS~notify@"] = LABEL_ID_FOR_DEE_DEE + "|INBOX",
                ["FROM~CONTAINS~notification@"] = LABEL_ID_FOR_DEE_DEE + "|INBOX",
                ["FROM~CONTAINS~reply@"] = LABEL_ID_FOR_DEE_DEE + "|INBOX",
                ["FROM~CONTAINS~update@"] = LABEL_ID_FOR_DEE_DEE + "|INBOX",
                ["FROM~CONTAINS~updates@"] = LABEL_ID_FOR_DEE_DEE + "|INBOX",
            };
            var rulesCsv = StringDictionaryHelperStatic.DictionaryToDelimitedString(rules, ',', '=');
            var resultingRules = StringHelperStatic.SplitStringToDictionary(rulesCsv, '=', ',');
        }
    }
}