/********************************************************************************
 * Univeral Content Processing Engine
 * 
 * This engine accepts a piece of content from a source and determines its type 
 * and how to process it. This engine uses unsupervised learning to extend itself. 
 * It also provides a console for supervised learning sessions.
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 ********************************************************************************/

namespace TestTextString
{
    using CSHARP.V8.Helpers.TextString;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class TestStringValidationHelper
    {
        [TestMethod]
        public void Test_001_001_TestIsBase64_EmptyString()
        {
            Assert.IsFalse(Base64HelperStatic.IsBase64(string.Empty));

            Base64Helper base64Helper = new Base64Helper();
            Assert.IsFalse(base64Helper.IsBase64(string.Empty));
        }
    }
}
