/********************************************************************************
 * CSHARP Text Library - General utility to manipulate text strings
 * 
 * NOTE: Adapted from Clinch.Text
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 *          
 * CHANGES: 
 * 
 *  - (v5.0) All methods converted to static
 *  - (v5.0) Additional code to check parameters passed to exit method quicker
 *  - (v8.0) Upgraded to NET8.0 
 *  
 *  POSSIBLE FUTURE IMPROVEMENTS
 *  
 *  -
 *  
 ********************************************************************************/

namespace CSHARP.V8.Helpers.TextString
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Text.RegularExpressions;

    /// <summary>
    /// General function to help manupulate strings
    /// </summary>
    public class StringHelper
    {
        #region 001 - Parse Regex 

        /// <summary>
        /// Regular Expression used to extract email address
        /// </summary>
        public const string EmailAddressRegex = @"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";

        /// <summary>
        /// Alternative regex for extracting email
        /// </summary>
        public const string EmailAddressRegex2 = @"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?";
        private static readonly Regex SocialProfileRegex = new Regex(@"(http(s)?:\/\/)?([\w]+\.)?(linkedin\.com|facebook\.com|github\.com|stackoverflow\.com|bitbucket\.org|sourceforge\.net|(\w+\.)?codeplex\.com|code\.google\.com).*?(?=\s)", RegexOptions.Compiled | RegexOptions.IgnoreCase);

        /// <summary>
        /// Regular Expression used to extract phone number
        /// </summary>
        public const string PhoneRegex = @"(\(\+[0-9]{1,3}\)[\.\s]?)?[0-9]{7,14}(?:x.+)?";

        /// <summary>
        /// Second alternative to find phone number
        /// </summary>
        public const string PhoneRegex2 = @"(?<Telephone>([0-9]|[ ]|[-]|[\(]|[\)]|ext.|[,])+)([ ]|[:]|\t|[-])*(?<Where>Home|Office|Work|Away|Fax|FAX|Phone)|(?<Where>Home|Office|Work|Away|Fax|FAX|Phone|Daytime|Evening)([ ]|[:]|\t|[-])*(?<Telephone>([0-9]|[ ]|[-]|[\(]|[\)]|ext.|[,])+)|(?<Telephone>([(]([0-9]){3}[)]([ ])?([0-9]){3}([ ]|-)([0-9]){4}))";

        /// <summary>
        /// Third alternative to find phone number
        /// </summary>
        public const string PhoneRegex3 = @"[01]?[- .]?(\([2-9]\d{2}\)|[2-9]\d{2})[- .]?\d{3}[- .]?\d{4}$";

        /// <summary>
        /// Get all strings that match the given expression in the text provided
        /// </summary>
        /// <param name="text">Text containing the pattern</param>
        /// <param name="regexPattern">RexEx Pattern to check for</param>
        /// <returns></returns>
        /// <remarks>v8.0.1.2 return value changed to string array</remarks>
        public string[] GetAllMatches(string text, string regexPattern)
        {
            return StringHelperStatic.GetAllMatches(text, regexPattern);
        }

        /// <summary>
        /// Get all strings that match the given expression in the text provided
        /// </summary>
        /// <param name="text">Text containing the pattern</param>
        /// <param name="regexPatterns">RexEx Pattern to check for</param>
        /// <returns></returns>
        /// <remarks>v8.0.1.2 return value changed to string array</remarks>
        public string[]? GetAllMatchesViaLoop(string text, string[] regexPatterns)
        {
            return StringHelperStatic.GetAllMatchesViaLoop(text, regexPatterns);
        }

        #endregion

        #region 002 - ConvertToAlphaNumeric

        /// <summary>
        /// Removes all non-alpha-numeric from string.
        /// </summary>
        /// <param name="toConvert">String to remove alpha-numeric from</param>
        /// <param name="removeWhiteSpace">if true removes spaces and, tabs.</param>
        /// <returns>alpha-numeric string</returns>
        public string ConvertToAlphaNumeric(string toConvert, bool removeWhiteSpace)
        {
            return StringHelperStatic.ConvertToAlphaNumeric(toConvert, removeWhiteSpace);
        }

        /// <summary>
        /// Converts all non-alpha-numeric to spaces in the string.  
        /// Removes White Spaces and Underscores if requested
        /// </summary>
        /// <param name="toConvert">String to remove alpha-numeric from</param>
        /// <param name="removeWhiteSpace">if true removes spaces and, tabs.</param>
        /// <param name="removeUnderScore">if true reomoves underscores</param>
        /// <returns>alpha-numeric string</returns>
        public static string ConvertToAlphaNumeric(string toConvert, bool removeWhiteSpace, bool removeUnderScore)
        {
            return StringHelperStatic.ConvertToAlphaNumeric(toConvert, removeWhiteSpace, removeUnderScore);
        }
        /// <summary>
        /// Converts all non-alpha-numeric to spaces in the string.  
        /// </summary>
        /// <param name="toConvert">String to remove alpha-numeric from</param>
        /// <param name="removeWhiteSpace">if true removes spaces and, tabs.</param>
        /// <param name="removeUnderScore">if true removes underscores</param>
        /// <param name="replaceSpaceWithUnderScore">if true and we are not removing space or underscores then replaces all spaces with underscore</param>
        /// <param name="consolidateConsecutiveUnderscores">if true and we are not removing space or underscores then replaces all consecutive underscores with a single underscore</param>
        /// <returns></returns>
        /// <remarks>NEW IN v5.0.0.0</remarks>
        public string ConvertToAlphaNumeric(string toConvert, bool removeWhiteSpace, bool removeUnderScore, bool replaceSpaceWithUnderScore, bool consolidateConsecutiveUnderscores)
        {
            return StringHelperStatic.ConvertToAlphaNumeric(toConvert, removeWhiteSpace, removeUnderScore, replaceSpaceWithUnderScore, consolidateConsecutiveUnderscores, false);
        }

        #endregion

        #region 003 - Random String

        /// <summary>
        /// Generates an 8 character random string based on random filename function
        /// </summary>
        /// <returns>8 character random number</returns>
        public string Get8CharacterRandomString()
        {
            return StringHelperStatic.Get8CharacterRandomString();
        }

        #endregion

        #region 004 - Convert To Csv

        /// <summary>
        /// Converts a list of objects to string containing CSV including header row
        /// </summary>
        /// <param name="collection">Collection of objects to generate CSV from</param>
        /// <param name="type">type of object being generated</param>
        /// <returns>csv string</returns>
        /// <remarks>V2.0.0.2 Case Corrected in method name</remarks>
        public string ConvertToCsv(IEnumerable collection, Type type)
        {
            return StringHelperStatic.ConvertToCsv(collection, type);
        }

        #endregion

        #region 005 - UrlFriendly 

        /// <summary>
        /// Converts an url friendly string by replacing all non-alphanumeric and spaces with an alternate string
        /// </summary>
        /// <param name="toConvert">String to convert</param>
        /// <param name="replaceUnfriendlyWith">string to replace non-friendly characters with</param>
        /// <returns></returns>
        /// <remarks>NEW in V2.0.0.8
        /// 2.0.0.10 - Spaces were being replaced with empty string rather than replaceUnfriendlyWith
        /// </remarks>
        public static string ConvertToUrlFriendly(string toConvert, string replaceUnfriendlyWith)
        {
            return StringHelperStatic.ConvertToUrlFriendly(toConvert, replaceUnfriendlyWith);
        }

        #endregion

        #region 006 - Dictionary To ... 

        /// <summary>
        /// Takes the pairs from the string,string dictionary and converts them to a delimited string
        /// </summary>
        /// <param name="stringDictionary">Dictionary with a string key and string value</param>
        /// <param name="pairToken">token to put between each pair</param>
        /// <param name="partToken">token to put between the key and value</param>
        /// <returns>Delimited string however if the value contains the partToken or pairToken it will be Base64 Encoded</returns>
        /// <remarks>NEW IN v5.0.0.0. Allowed passsing character tokens instead of strings </remarks>
        public string DictionaryToDelimitedString(Dictionary<string, string> stringDictionary, char pairToken, char partToken)
        {
            return StringDictionaryHelperStatic.DictionaryToDelimitedString(stringDictionary, pairToken, partToken);
        }

        /// <summary>
        /// Takes the pairs from the string,string dictionary and converts them to a delimited string
        /// </summary>
        /// <param name="stringDictionary">Dictionary with a string key and string value</param>
        /// <param name="pairToken">token to put between each pair</param>
        /// <param name="partToken">token to put between the key and value</param>
        /// <returns>Delimited string however if the value contains the partToken or pairToken it will be Base64 Encoded</returns>
        public string DictionaryToDelimitedString(Dictionary<string, string> stringDictionary, string pairToken, string partToken)
        {
            return StringDictionaryHelperStatic.DictionaryToDelimitedString(stringDictionary, pairToken, partToken);
        }

        #endregion

        #region 007 - String Splitters

        /// <summary>
        /// Splits a string into its words for manipulation
        /// </summary>
        /// <param name="toSplit">String to split into words</param>
        /// <returns></returns>
        /// <remarks>v 8.0.1.2 return value changed to string array
        /// Uses default values to split words</remarks>
        public string[] SplitStringIntoWords(string toSplit)
        {
            return StringHelperStatic.SplitStringIntoWords(toSplit);
        }

        /// <summary>
        /// Splits a string into its words for manipulation
        /// </summary>
        /// <param name="toSplit">String to split into words</param>
        /// <param name="endOfWordToken"></param>
        /// <returns></returns>
        /// <remarks>v8.0.1.2 return value changed to string array
        /// v2.0.0.11 Strips string before splitting into words</remarks>
        public string[] SplitStringIntoWords(string toSplit, char[] endOfWordToken)
        {
            return StringHelperStatic.SplitStringIntoWords(toSplit, endOfWordToken);
        }

        /// <summary>
        /// Splits a string into sentences for manipulation
        /// </summary>
        /// <param name="toSplit"></param>
        /// <returns></returns>
        /// <remarks>v8.0.1.1 - converted return value to string array</remarks>
        public string[] SplitStringIntoSentences(string toSplit)
        {
            return StringHelperStatic.SplitStringIntoSentences(toSplit);
        }

        /// <summary>
        /// Gets the first line in the string
        /// </summary>
        /// <param name="toSplit">string containing lines</param>
        /// <returns></returns>
        public static string GetFirstLine(string toSplit)
        {
            return StringHelperStatic.GetFirstLine(toSplit);
        }

        /// <summary>
        /// Splits a string into lines for manipulation
        /// </summary>
        /// <param name="toSplit">string containing lines</param>
        /// <returns></returns>
        public string[] SplitStringIntoLines(string toSplit)
        {
            return StringHelperStatic.SplitStringIntoLines(toSplit);
        }

        /// <summary>
        /// Splits the string to dictionary given tokens.
        /// </summary>
        /// <param name="toSplit">string to split</param>
        /// <param name="keyValueToken">token to split key and value</param>
        /// <param name="entryToken">token to split each dictionary entry</param>
        /// <returns></returns>
        /// <remarks>NEW in v2.0.0.3</remarks>
        public Dictionary<string, string> SplitStringToDictionary(string toSplit, char keyValueToken, char entryToken)
        {
            return StringHelperStatic.SplitStringToDictionary(toSplit, keyValueToken, entryToken);
        }

        /// <summary>
        /// Splits the string to dictionary given keyvalue token. This assumes one pair per line
        /// </summary>
        /// <param name="toSplit">string to split</param>
        /// <param name="keyValueToken">token to split key and value</param>
        /// <returns></returns>
        /// <remarks>NEW in v5.0.0.0</remarks>
        public Dictionary<string, string> SplitStringToDictionary(string toSplit, char keyValueToken)
        {
            return StringHelperStatic.SplitStringToDictionary(toSplit, keyValueToken);
        }

        /// <summary>
        /// Splits the string to dictionary given tokens, only including duplicate keys once.
        /// </summary>
        /// <param name="toSplit">string to split</param>
        /// <param name="keyValueToken">token to split key and value</param>
        /// <param name="entryToken">token to split each dictionary entry</param>
        /// <returns></returns>
        /// <remarks>NEW in v2.0.0.5</remarks>
        public Dictionary<string, string> SplitStringToDistinctDictionary(string toSplit, char keyValueToken, char entryToken)
        {
            return StringHelperStatic.SplitStringToDistinctDictionary(toSplit, keyValueToken, entryToken);
        }


        /// <summary>
        /// Splits the string to dictionary on the end of line marker.
        /// </summary>
        /// <param name="input">string to split</param>
        /// <param name="token">token to split key and value</param>
        /// <returns></returns>
        /// <remarks>FIX: 2.0.0.2 - Exception on Line with key and no value</remarks>
        public Dictionary<string, string> SplitStringToDictionaryOnEndOfLine(string input, char token)
        {
            return StringHelperStatic.SplitStringToDictionaryOnEndOfLine(input, token);
        }

        /// <summary>
        /// Splits the string on the end of line marker.
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public string[] SplitStringOnEndOfLine(string input)
        {
            return StringHelperStatic.SplitStringOnEndOfLine(input);
        }

        /// <summary>
        /// Splits the string on the end of line marker. Only include distinct strings
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        /// <remarks>NEW in 2.0.0.6</remarks>
        public string[] SplitStringOnEndOfLineDistinct(string input)
        {
            return StringHelperStatic.SplitStringOnEndOfLineDistinct(input);
        }

        #endregion

        #region 008 - StringArray To ...

        /// <summary>
        /// Builds a delimited string from a string array. Only include distinct strings
        /// </summary>
        /// <param name="items">array of strings</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        /// <remarks>NEW in 2.0.0.6</remarks>
        public string StringArrayToDistinctDelimitedString(string[] items, char token)
        {
            return StringArrayHelperStatic.StringArrayToDistinctDelimitedString(items, token);
        }

        /// <summary>
        /// Builds a delimited string from a string array
        /// </summary>
        /// <param name="items">array of strings</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        public string StringArrayToDelimitedString(string[] items, char token)
        {
            return StringArrayHelperStatic.StringArrayToDelimitedString(items, token);
        }

        #endregion

        #region 009 - StringList To ...

        /// <summary>
        /// Builds a delimited string from a list of strings
        /// </summary>
        /// <param name="items">list of strings</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        /// <remarks>v5.0.0.0 char version now calls the new string version</remarks>
        public string StringListToDelimitedString(List<string> items, char token)
        {
            return StringListHelperStatic.StringListToDelimitedString(items, token);
        }

        /// <summary>
        /// Builds a delimited string from a list of strings
        /// </summary>
        /// <param name="items">list of strings</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        /// <remarks>NEW IN v5.0.0.0. This version allows you to pass a string for a token to support multi-character tokens eg. || </remarks>
        public string StringListToDelimitedString(List<string> items, string token)
        {
            return StringListHelperStatic.StringListToDelimitedString(items, token);
        }

        /// <summary>
        /// Builds a string containing a string per line from a delimited string 
        /// </summary>
        /// <param name="items">list of strings</param>
        /// <returns></returns>
        /// <remarks>NEW in 2.0.0.7</remarks>
        public string StringListToEndOfLineDelimited(List<string> items)
        {
            return StringListHelperStatic.StringListToEndOfLineDelimited(items);
        }

        #endregion

        #region 010 - Delimited String To ...

        /// <summary>
        /// Builds an array of strings from a delimited string 
        /// </summary>
        /// <param name="delimitedString">delimited string</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        /// <remarks>FIXED v2.0.0.10 - Returns null if null passed in</remarks>
        public List<Guid>? DelimitedStringToGuidList(string delimitedString, char token)
        {
            return StringHelperStatic.DelimitedStringToGuidList(delimitedString, token);
        }

        /// <summary>
        /// Builds an array of strings from a delimited string 
        /// </summary>
        /// <param name="delimitedString">delimited string</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        /// <remarks>FIXED v2.0.0.10 - Returns null if null passed in</remarks>
        public string[]? DelimitedStringToStringArray(string delimitedString, char token)
        {
            return StringHelperStatic.DelimitedStringToStringArray(delimitedString, token);
        }

        /// <summary>
        /// Builds a list of strings from a delimited string 
        /// </summary>
        /// <param name="delimitedString">delimited string</param>
        /// <param name="token">character delimiter</param>
        /// <returns></returns>
        /// <remarks>FIXED v2.0.0.10 - Returns null if null passed in</remarks>
        public List<string>? DelimitedStringToStringList(string delimitedString, char token)
        {
            return StringHelperStatic.DelimitedStringToStringList(delimitedString, token);
        }

        /// <summary>
        /// Builds a list of strings from a delimited string 
        /// </summary>
        /// <param name="delimitedString">delimited string</param>
        /// <param name="token">string delimiter</param>
        /// <returns></returns>
        /// <remarks>NEW IN v5.0.0.0 - Returns null if null passed in</remarks>
        public List<string>? DelimitedStringToStringList(string delimitedString, string token)
        {
            return StringHelperStatic.DelimitedStringToStringList(delimitedString, token);
        }

        /// <summary>
        /// Builds an array of strings from a delimited string 
        /// </summary>
        /// <param name="delimitedString">delimited string</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        /// <remarks>FIXED v2.0.0.10 - Returns null if null passed in</remarks>
        public string[]? DelimitedStringToStringArray(string delimitedString, string token)
        {
            return StringHelperStatic.DelimitedStringToStringArray(delimitedString, token);
        }

        /// <summary>
        /// Builds a string containing a string per line from a delimited string 
        /// </summary>
        /// <param name="delimitedString">delimited string</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        /// <remarks>FIXED v2.0.0.10 - Returns null if null passed in</remarks>
        public string? DelimitedStringToEndOfLineDelimited(string delimitedString, string token)
        {
            return StringHelperStatic.DelimitedStringToEndOfLineDelimited(delimitedString, token);
        }

        #endregion

        #region 011 - GuidList To ...

        /// <summary>
        /// Builds a delimited string from a list of strings
        /// </summary>
        /// <param name="items">list of strings</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        public string GuidListToDelimitedString(List<Guid> items, char token)
        {
            return StringHelperStatic.GuidListToDelimitedString(items, token);
        }

        #endregion

        #region 012 - GetAfter 

        /// <summary>
        /// Removes all text after the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <returns></returns>
        public string GetAfter(string snippet, string token)
        {
            return StringHelperStatic.GetAfter(snippet, token);
        }
        /// <summary>
        /// Removes all text after the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public string GetAfter(string snippet, string token, bool including)
        {
            return StringHelperStatic.GetAfter(snippet, token, including);
        }
        /// <summary>
        /// Removes all text after the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public string GetAfter(string snippet, string token, string including)
        {
            return StringHelperStatic.GetAfter(snippet, token, including);
        }

        /// <summary>
        /// Removes all text after the first occurence of one of the given tokens
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="tokens">array of tokens to look for</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        /// <remarks>NEW In v2.0.0.9</remarks>
        public string GetAfterOneOf(string snippet, char[] tokens, string including)
        {
            return StringHelperStatic.GetAfterOneOf(snippet, tokens, including);
        }

        #endregion

        #region 013 - GetAfterLast 

        /// <summary>
        /// Removes all text after the last occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public string GetAfterLast(string snippet, string token, bool including)
        {
            return StringHelperStatic.GetAfterLast(snippet, token, including);
        }

        /// <summary>
        /// Removes all text after the last occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public string GetAfterLast(string snippet, string token, string including)
        {
            return StringHelperStatic.GetAfterLast(snippet, token, including);
        }

        #endregion

        #region 014 - GetAfterPosition

        /// <summary>
        /// Gets text after a given position
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="position">position to get content after</param>
        /// <returns></returns>
        public string GetAfterPosition(string snippet, int position)
        {
            return StringHelperStatic.GetAfterPosition(snippet, position);
        }

        #endregion

        #region 015 - DeleteAfter

        /// <summary>
        /// Removes all text after the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <returns></returns>
        public string DeleteAfter(string snippet, string token)
        {
            return StringHelperStatic.DeleteAfter(snippet, token);
        }

        /// <summary>
        /// Removes all text after the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public string DeleteAfter(string snippet, string token, bool including)
        {
            return StringHelperStatic.DeleteAfter(snippet, token, including);
        }
        /// <summary>
        /// Removes all text after the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public string DeleteAfter(string snippet, string token, string including)
        {
            return StringHelperStatic.DeleteAfter(snippet, token, including);
        }

        #endregion

        #region 016 - DeleteAfterLast 

        /// <summary>
        /// Removes all text after the last occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public static string DeleteAfterLast(string snippet, string token, bool including)
        {
            return StringHelperStatic.DeleteAfterLast(snippet, token, including);
        }

        /// <summary>
        /// Removes all text after the last occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public string DeleteAfterLast(string snippet, string token, string including)
        {
            return StringHelperStatic.DeleteAfterLast(snippet, token, including);
        }

        #endregion

        #region 017 - FindOneOf

        /// <summary>
        /// Finds the first occurance of one of the characters in the tokens string in the snippet
        /// </summary>
        /// <param name="snippet">String to search inside</param>
        /// <param name="tokens">character tokens to search for inside snippet</param>
        /// <returns></returns>
        public int FindOneOf(string snippet, char[] tokens)
        {
            return StringHelperStatic.FindOneOf(snippet, tokens);
        }

        #endregion

        #region 018 - GetFirst

        /// <summary>
        /// Gets the first x characters in a string
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="length">number of characters to get from the beginning for the string</param>
        /// <returns></returns>
        public string GetFirst(string snippet, int length)
        {
            return StringHelperStatic.GetFirst(snippet, length);
        }

        /// <summary>
        /// Gets the first x characters in a string
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="length">number of characters to get from the beginning for the string</param>
        /// <param name="addEllipsis">if true, will reduce length by an addition 3 characters and adds ... to the end</param>
        /// <returns></returns>
        public string GetFirst(string snippet, int length, bool addEllipsis)
        {
            return StringHelperStatic.GetFirst(snippet, length, addEllipsis);
        }

        #endregion

        #region 019 - GetLast

        /// <summary>
        /// Gets the last x characters in a string
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="length">number of characters to get from the end for the string</param>
        /// <returns></returns>
        public string GetLast(string snippet, int length)
        {
            return StringHelperStatic.GetLast(snippet, length);
        }

        #endregion

        #region 020 - GetBefore 

        /// <summary>
        /// Removes all text before the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <returns></returns>
        public string GetBefore(string snippet, string token)
        {
            return StringHelperStatic.GetBefore(snippet, token);
        }

        /// <summary>
        /// Removes all text before the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public string GetBefore(string snippet, string token, bool including)
        {
            return StringHelperStatic.GetBefore(snippet, token, including);
        }

        /// <summary>
        /// Removes all text before the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public string GetBefore(string snippet, string token, string including)
        {
            return StringHelperStatic.GetBefore(snippet, token, including);
        }

        /// <summary>
        /// Removes all text before the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="tokens">array of tokens to look for</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        /// <remarks>NEW in v2.0.0.9</remarks>
        public string GetBeforeOneOf(string snippet, char[] tokens, string including)
        {
            return StringHelperStatic.GetBeforeOneOf(snippet, tokens, including);
        }

        #endregion

        #region 021 - GetBeforeLast 

        /// <summary>
        /// Removes all text after the last occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <returns></returns>
        public string GetBeforeLast(string snippet, string token)
        {
            return StringHelperStatic.GetBeforeLast(snippet, token);
        }

        /// <summary>
        /// Removes all text after the last occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public string GetBeforeLast(string snippet, string token, bool including)
        {
            return StringHelperStatic.GetBeforeLast(snippet, token, including);
        }

        /// <summary>
        /// Removes all text after the last occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public string GetBeforeLast(string snippet, string token, string including)
        {
            return StringHelperStatic.GetBeforeLast(snippet, token, including);
        }

        #endregion

        #region 022 - GetBeforePosition 

        /// <summary>
        /// Removes all text after a given position in a string
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="position">position to get content before</param>
        /// <returns></returns>
        public string GetBeforePosition(string snippet, int position)
        {
            return StringHelperStatic.GetBeforePosition(snippet, position);
        }

        #endregion

        #region 023 - DeleteBefoe

        /// <summary>
        /// Removes all text before the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <returns></returns>
        public string DeleteBefore(string snippet, string token)
        {
            return StringHelperStatic.DeleteBefore(snippet, token);
        }

        /// <summary>
        /// Removes all text before the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public string DeleteBefore(string snippet, string token, bool including)
        {
            return StringHelperStatic.DeleteBefore(snippet, token, including);
        }

        /// <summary>
        /// Removes all text before the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public string DeleteBefore(string snippet, string token, string including)
        {
            return StringHelperStatic.DeleteBefore(snippet, token, including);
        }

        #endregion

        #region 024 - DeleteBeforePosition 

        /// <summary>
        /// Removes all text before the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="position">position to delete content before</param>
        /// <returns></returns>
        public string DeleteBeforePosition(string snippet, int position)
        {
            return StringHelperStatic.DeleteBeforePosition(snippet, position);
        }

        #endregion

        #region 025 - GetBetween 

        /// <summary>
        /// Gets the string content between the beforeToken and afterToken.
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="afterToken"></param>
        /// <param name="beforeToken"></param>
        /// <param name="including"></param>
        /// <returns></returns>
        public string GetBetween(string snippet, string afterToken, string beforeToken, bool including)
        {
            return StringHelperStatic.GetBetween(snippet, afterToken, beforeToken, including);
        }

        /// <summary>
        /// Gets the string content between the beforeToken and afterToken.
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="afterToken"></param>
        /// <param name="beforeToken"></param>
        /// <param name="including"></param>
        /// <returns></returns>
        /// <remarks>FIXED v2.0.0.4 - Including was missing before token</remarks>
        public string GetBetween(string snippet, string afterToken, string beforeToken, string including)
        {
            return StringHelperStatic.GetBetween(snippet, afterToken, beforeToken, including);
        }

        #endregion

        #region 026 - GetBetweenPositions

        /// <summary>
        /// Gets the string content between two positions.
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="afterPosition"></param>
        /// <param name="beforePosition"></param>
        /// <param name="beforeTokenLength"></param>
        /// <returns></returns>
        /// <remarks>FIXED v2.0.0.4 - Including was missing before token</remarks>
        public string GetBetweenPositions(string snippet, int afterPosition, int beforePosition, int beforeTokenLength)
        {
            return StringHelperStatic.GetBetweenPositions(snippet, afterPosition, beforePosition, beforeTokenLength);
        }

        #endregion

        #region 027 - ReplaceLast

        /// <summary>
        /// Replaces the last occurence of a given token with the replacement string
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="replaceWith"></param>
        /// <returns></returns>
        public string ReplaceLast(string snippet, string token, string replaceWith)
        {
            return StringHelperStatic.ReplaceLast(snippet, token, replaceWith);
        }

        #endregion

        #region 028 - GetEverythingBetweenBraces

        /// <summary>
        /// This function will look for the matching end brace. It handles nested braces as long as they ALL match.
        /// </summary>
        /// <param name="snippetStartingWithOpenBrace">The starting brace MUST be the first character</param>
        /// <param name="including">if true the return value will include open and closing brace in the result</param>
        /// <param name="snippetAfterCloseBrace">out parameter that will get everything after the matching closing brace.</param>
        /// <returns>If matching brace found returns everything between the matching braces (including the braces if specified)
        /// </returns>
        /// <exception cref="ArgumentException">This is thrown if snippetStartingWithOpenBrace does not start with the brace</exception>
        /// <exception cref="Exception">This is thrown if we cant find the matching end brace.</exception>
        public string GetEverythingBetweenBraces(string snippetStartingWithOpenBrace, bool including, out string snippetAfterCloseBrace)
        {
            return StringHelperStatic.GetEverythingBetweenBraces(snippetStartingWithOpenBrace, including, out snippetAfterCloseBrace);
        }

        #endregion
    }
}
