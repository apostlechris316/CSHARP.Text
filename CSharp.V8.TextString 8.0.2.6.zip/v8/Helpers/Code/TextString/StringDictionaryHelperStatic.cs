/********************************************************************************
 * CSHARP Text Library - General utility to manipulate text strings
 * 
 * NOTE: Adapted from Clinch.Text
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 *          
 * CHANGES: 
 * 
 *  - (v5.0) All methods converted to static
 *  - (v5.0) Additional code to check parameters passed to exit method quicker
 *  - (v8.0) Upgraded to NET8.0 
 *  
 * FUTURE IMPROVEMENTS:
 *  
 *  -
 *  
 ********************************************************************************/

namespace CSHARP.V8.Helpers.TextString
{
    using System.Collections.Generic;
    using System.Text;
 
    /// <summary>
    /// General function to help manupulate strings
    /// </summary>
    public static class StringDictionaryHelperStatic
    {
        #region 006 - Dictionary To ... 

        /// <summary>
        /// Takes the pairs from the string,string dictionary and converts them to a delimited string
        /// </summary>
        /// <param name="stringDictionary">Dictionary with a string key and string value</param>
        /// <param name="pairToken">token to put between each pair</param>
        /// <param name="partToken">token to put between the key and value</param>
        /// <returns>Delimited string however if the value contains the partToken or pairToken it will be Base64 Encoded</returns>
        /// <remarks>NEW IN v5.0.0.0. Allowed passsing character tokens instead of strings </remarks>
        public static string DictionaryToDelimitedString(Dictionary<string, string> stringDictionary, char pairToken, char partToken)
        {
            return DictionaryToDelimitedString(stringDictionary, pairToken.ToString(), partToken.ToString());
        }

        /// <summary>
        /// Takes the pairs from the string,string dictionary and converts them to a delimited string
        /// </summary>
        /// <param name="stringDictionary">Dictionary with a string key and string value</param>
        /// <param name="pairToken">token to put between each pair</param>
        /// <param name="partToken">token to put between the key and value</param>
        /// <returns>Delimited string however if the value contains the partToken or pairToken it will be Base64 Encoded</returns>
        public static string DictionaryToDelimitedString(Dictionary<string, string> stringDictionary, string pairToken, string partToken)
        {
            var csvString = new StringBuilder();
            foreach (var item in stringDictionary)
            {
                // each pair is separated by a pipe
                if (csvString.Length > 0)
                {
                    csvString.Append(pairToken);
                }

                var value = (string.IsNullOrEmpty(item.Value) ? string.Empty : item.Value);

                if (value.Contains(partToken) || value.Contains(pairToken))
                {
                    // if it contains a we base64 it
                    csvString.Append(item.Key + partToken + "BASE64:" + Base64HelperStatic.Base64Encode(value));
                }
                else
                {
                    csvString.Append(item.Key + partToken + value);
                }
            }

            return csvString.ToString();
        }

        #endregion

        #region 029 Dictionary Validation

        /// <summary>
        /// If the first and second dictionary are identical
        /// </summary>
        /// <param name="first">dictionary of strings to compare</param>
        /// <param name="second">dictionary of string to comare to the first</param>
        /// <returns></returns>
        /// <remarks>V8.0.1.9 Allow to pass null and we will perform the check. This simplifies code for the caller.
        /// NEW IN v8.0.0.3</remarks>
        public static bool IsSameDictionary(Dictionary<string, string>? first, Dictionary<string, string>? second)
        {
            // if both are null then yes technically same list
            if (first == null && second == null) return true;

            // if only one is null then they are not
            if (first == null || second == null) return false;

            if (first.Count != second.Count) return false;

            foreach (string key in first.Keys)
            {
                if (second.ContainsKey(key) == false) return false;
                if (first[key] != second[key]) return false;
            }

            return true;
        }

        #endregion

        #region Dictionary Manipulation

        /// <summary>
        /// Adds values to the dictionary only if they are missing
        /// </summary>
        /// <param name="stringDictionary">string dictionary to add the values to</param>
        /// <param name="values">A string dictionary containing the values to add</param>
        /// <returns></returns>
        public static Dictionary<string,string> AddMissingStringPairsToDictionary(Dictionary<string,string>? stringDictionary, Dictionary<string,string> values)
        {
            if (null == stringDictionary) return values;

            var resultingStringDictionary = stringDictionary;
            foreach (var value in resultingStringDictionary)
            {
                if (false == resultingStringDictionary.ContainsKey(value.Key)) resultingStringDictionary.Add(value.Key, value.Value);
            }
            return resultingStringDictionary;
        }

        #endregion
    }
}
