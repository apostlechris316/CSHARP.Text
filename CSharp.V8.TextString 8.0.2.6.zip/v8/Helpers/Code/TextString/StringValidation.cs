﻿/********************************************************************************
 * CSHARP Text Library - General utility to manipulate text strings
 * 
 * NOTE: Adapted from Clinch.Text
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 *          
 * CHANGES: 
 * 
 *  - (v5.0) All methods converted to static
 *  - (v5.0) Additional code to check parameters passed to exit method quicker
 *  - (v8.0) Upgraded to NET8.0 
 *  
 *  POSSIBLE FUTURE IMPROVEMENTS
 *  
 *  -
 *  
 ********************************************************************************/

namespace CSHARP.V8.Helpers.TextString
{
    using System;
    using System.Text.RegularExpressions;

    /// <summary>
    /// Functions to assist in validating strings
    /// </summary>
    public class StringValidation
    {
        /// <summary>
        /// Types of data that is storeable in a string
        /// </summary>
        public enum ValidStringTypes
        {
            /// <summary>
            /// All types of data that is storeable in a string
            /// </summary>
            All,
            /// <summary>
            /// Letters can be storeable in a string
            /// </summary>
            Alpha,
            /// <summary>
            /// Letters and numbers can be storeable in a string
            /// </summary>
            AlphaNumeric,
            /// <summary>
            /// Email addresses can be storeable in a string
            /// </summary>
            Email,
            /// <summary>
            /// Integers can be storeable in a string
            /// </summary>
            Integer,
            /// <summary>
            /// Natural numbers can be storeable in a string
            /// </summary>
            NaturalNumber,
            /// <summary>
            /// Numbers can be storeable in a string
            /// </summary>
            Number,
            /// <summary>
            /// Phone numbers can be storeable in a string
            /// </summary>
            Phone,
            /// <summary>
            /// Positive numbers can be storeable in a string
            /// </summary>
            PositiveNumber,
            /// <summary>
            /// Postal Codes can be storeable in a string
            /// </summary>
            PostalCode,
            /// <summary>
            /// Urls can be storeable in a string
            /// </summary>
            Url,
            /// <summary>
            /// Whole numbers can be storeable in a string
            /// </summary>
            WholeNumber,
            /// <summary>
            /// Zip Codes can be storeable in a string
            /// </summary>
            ZipCode
        }

        #region Validation Regex 

        /// <summary>
        /// Regular Expression used to validate string is not an integer
        /// </summary>
        public const string NotIntegerRegex = "[^0-9-]";

        /// <summary>
        /// Regular Expression used to validate string is not a natural number
        /// </summary>
        public const string NotNaturalNumberRegex = "[^0-9]";

        /// <summary>
        /// Regular Expression used to validate string is not a whole number
        /// </summary>
        public const string NotWholeNumberRegex = "[^0-9]";

        /// <summary>
        /// Regular Expression used to validate string is not an positive number
        /// </summary>
        public const string NotPositiveNumberRegex = "[^0-9.]";

        /// <summary>
        /// Regular Expression used to validate string is not a number
        /// </summary>
        public const string NotNumberRegex = "^[0-9.-]";

        /// <summary>
        /// Regular Expression used to validate strings with alphabet characters only
        /// </summary>
        public const string AlphaRegex = "^[a-zA-Z]*$";

        /// <summary>
        /// Regular Expression used to validate strings with alphabet characters only
        /// </summary>
        /// <remarks>NEW in v.2.0.0.12</remarks>
        public const string AlphaRegexAllowSpace = @"^[a-zA-Z\s]*$";

        /// <summary>
        /// Regular Expression used to validate string with alphabet and numeric characters
        /// </summary>
        public const string AlphaNumericRegex = "^[a-zA-Z0-9]*$";

        /// <summary>
        /// Regular Expression used to validate string with alphabet and numeric characters
        /// </summary>
        /// <remarks>NEW in v.2.0.0.12</remarks>
        public const string AlphaNumericRegexAllowSpace = @"^[a-zA-Z0-9\s]*$";

        /// <summary>
        /// 
        /// </summary>
        public const string AlphaNumericOrUnderscoreRegex = "^[a-zA-Z0-9_]*$";

        /// <summary>
        /// 
        /// </summary>
        /// <remarks>NEW in v.2.0.0.12</remarks>
        public const string AlphaNumericOrUnderscoreRegexAllowSpace = @"[^a-zA-Z0-9_\s]*$";

        /// <summary>
        /// Regular Expression used to validate string with alphabet and numeric and dash
        /// </summary>
        public const string AlphaNumericOrDashRegex = @"[^a-zA-Z0-9\-]*$";

        /// <summary>
        /// Regular Expression used to validate string with alphabet and numberc and dash and space
        /// </summary>
        public const string AlphaNumericOrDashRegexAllowSpace = @"[^a-zA-Z0-9_\-\s]*$";

        /// <summary>
        /// Regular Expression used to validate string with alphabet and numberc and dot
        /// </summary>
        public const string AlphaNumericOrDotRegex = @"[^a-zA-Z0-9.]*$";

        /// <summary>
        /// Regular Expression used to validate string with alphabet and numberc and dot and space
        /// </summary>
        public const string AlphaNumericOrDotRegexAllowSpace = @"[^a-zA-Z0-9_.\-\s]*$";

        /// <summary>
        /// Regular Expression used to validate string with alphabet and numeric and dot and dash
        /// </summary>
        public const string AlphaNumericOrDotOrDashRegex = @"[^a-zA-Z0-9.]*$";

        /// <summary>
        /// Regular Expression used to validate string with alphabet and numeric and dot and dash and space
        /// </summary>
        public const string AlphaNumericOrDotOrDashRegexAllowSpace = @"[^a-zA-Z0-9_.\-\s]*$";

        /// <summary>
        /// Alpha Numeric or Underscore or Dot or comma
        /// </summary>
        public const string AlphaNumericOrUnderscoreOrDotOrDashOrCommaRegex = @"^[a-zA-Z0-9_.,\-]*$";

        /// <summary>
        /// Alpha Numeric or Underscore or Dot or comma
        /// </summary>
        /// <remarks>NEW in v.2.0.0.12</remarks>
        public const string AlphaNumericOrUnderscoreOrDotOrDashOrCommaAllowSpaceRegex = @"^[a-zA-Z0-9_.,\-\s]*$";

        /// <summary>
        /// Regular Expression used to validate email addresses
        /// </summary>
        public const string EmailRegex = @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";

        /// <summary>
        /// Regular Expression used to validate integers
        /// </summary>
        public const string IntegerRegex = "^([-]|[0-9])[0-9]*$";

        /// <summary>
        /// Regular Expression used to validate natural numbers
        /// </summary>
        public const string NaturalNumberRegex = "0*[1-9][0-9]*";

        /// <summary>
        /// Regular Expression used to validate real numbers
        /// </summary>
        public const string RealNumberRegex = "^([-]|[.]|[-.]|[0-9])[0-9]*[.]*[0-9]+$";

        /// <summary>
        /// Regular Expression used to validate phone numbers
        /// </summary>
        public const string PhoneRegex = @"^[01]?[- .]?(\([2-9]\d{2}\)|[2-9]\d{2})[- .]?\d{3}[- .]?\d{4}$";

        /// <summary>
        /// Regular Expression used to validate positive numbers
        /// </summary>
        public const string PositiveNumberRegex = "^[.][0-9]+$|[0-9]*[.]*[0-9]+$";

        /// <summary>
        /// Regular Expression used to validate postal codes
        /// </summary>
        public const string PostalCodeRegex = "[A-Z]\\d[A-Z] \\d[A-Z]\\d";
        /// <summary>
        /// 
        /// </summary>
        public const string TwoDotPositiveNumberRegex = "[0-9]*[.][0-9]*[.][0-9]*";
        /// <summary>
        /// 
        /// </summary>
        public const string TwoMinusNumberRegex = "[0-9]*[-][0-9]*[-][0-9]*";

        /// <summary>
        /// Regular Expression used to validate Urls
        /// </summary>
        public const string UrlRegex = @"^(ht|f)tp(s?)\:\/\/[0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*(:(0-9)*)*(\/?)([a-zA-Z0-9\-\.\?\,\'\/\\\+&amp;%\$#_]*)?$";

        /// <summary>
        /// Regular Expression used to validate Zip Codes
        /// </summary>
        public const string ZipCodeRegex = "\\d{5}(-\\d{4})?";

        #endregion

        /// <summary>
        /// Removes any possible injection code
        /// </summary>
        /// <param name="text">Text to clean</param>
        /// <returns></returns>
        public string SAFE_TEXT(string text)
        {
            return StringValidationStatic.SAFE_TEXT(text);
        }

        #region Validator Functions (Is...)

        /// <summary>
        /// Returns true if string matches valid data type passed in
        /// </summary>
        /// <param name="validStringType">Type of data expected in text</param>
        /// <param name="text">string to validate</param>
        public bool IsValid(ValidStringTypes validStringType, string text)
        {
            switch (validStringType)
            {
                case ValidStringTypes.Alpha: return IsAlpha(text);
                case ValidStringTypes.AlphaNumeric: return IsAlphaNumeric(text);
                case ValidStringTypes.Email: return IsEmail(text);
                case ValidStringTypes.Integer: return IsInteger(text);
                case ValidStringTypes.NaturalNumber: return IsNaturalNumber(text);
                case ValidStringTypes.Number: return IsNumber(text);
                case ValidStringTypes.Phone: return IsPhoneNumber(text);
                case ValidStringTypes.PositiveNumber: return IsPositiveNumber(text);
                case ValidStringTypes.PostalCode: return IsPostalCode(text);
                case ValidStringTypes.Url: return IsUrl(text);
                case ValidStringTypes.WholeNumber: return IsWholeNumber(text);
                case ValidStringTypes.ZipCode: return IsZipCode(text);
                default: return true;
            }
        }

        /// <summary>
        /// Checks if the string passed in is a valid email address
        /// </summary>
        /// <param name="text">string to validate</param>
        /// <returns></returns>
        public bool IsEmail(string text)
        {
            return StringValidationStatic.IsEmail(text);
        }

        /// <summary>
        /// Checks if the string passed in is a valid phone number
        /// </summary>
        /// <param name="text">string to validate</param>
        /// <returns></returns>
        public bool IsPhoneNumber(string text)
        {
            return StringValidationStatic.IsPhoneNumber(text);
        }

        /// <summary>
        /// Checks if the string passed in is a valid postal code
        /// </summary>
        /// <param name="text">string to validate</param>
        /// <returns></returns>
        public bool IsPostalCode(string text)
        {
            return StringValidationStatic.IsPostalCode(text);
        }

        /// <summary>
        /// Checks if the string passed in is a valid url
        /// </summary>
        /// <param name="text">string to validate</param>
        /// <returns></returns>
        public bool IsUrl(string text)
        {
            return StringValidationStatic.IsUrl(text);
        }

        /// <summary>
        /// Checks if the string passed in is a valid zip code
        /// </summary>
        /// <param name="text">string to validate</param>
        /// <returns></returns>
        public bool IsZipCode(string text)
        {
            return StringValidationStatic.IsZipCode(text);
        }

        /// <summary>
        /// Checks if string passed in is a valid Positive Integer
        /// </summary>
        /// <param name="text">string containing number to validate</param>
        /// <returns></returns>
        public bool IsNaturalNumber(string text)
        {
            return StringValidationStatic.IsNaturalNumber(text);
        }

        /// <summary>
        /// Checks if string passed in is a valid Positive Integers with zero inclusive 
        /// </summary>
        /// <param name="text">string containing number to validate</param>
        /// <returns></returns>
        public bool IsWholeNumber(string text)
        {
            return StringValidationStatic.IsWholeNumber(text);
        }

        /// <summary>
        /// Checks if string passed in is a valid Integers both Positive and Negative 
        /// </summary>
        /// <param name="text">string containing number to validate</param>
        /// <returns></returns>
        public bool IsInteger(string text)
        {
            return StringValidationStatic.IsInteger(text);
        }

        /// <summary>
        /// Checks if string passed in is a valid Positive Number both Integer and Real 
        /// </summary>
        /// <param name="text">string containing number to validate</param>
        /// <returns></returns>
        public bool IsPositiveNumber(string text)
        {
            return StringValidationStatic.IsPositiveNumber(text);
        }

        /// <summary>
        /// Checks if string passed in is a valid number or not
        /// </summary>
        /// <param name="text">string containing number to validate</param>
        /// <returns></returns>
        public bool IsNumber(string text)
        {
            return StringValidationStatic.IsNumber(text);
        }

        /// <summary>
        /// Checks if string passed in is a valid Alphabets
        /// </summary>
        /// <param name="text">string containing number to validate</param>
        /// <returns></returns>
        public bool IsAlpha(string text)
        {
            return StringValidationStatic.IsAlpha(text);
        }

        /// <summary>
        /// Checks if string passed in is a valid Alphabets
        /// </summary>
        /// <param name="text">string containing number to validate</param>
        /// <param name="allowSpace"></param>
        /// <returns></returns>
        /// <remarks>v.2.0.0.12 now supports allowing spaces</remarks>
        public bool IsAlpha(string text, bool allowSpace)
        {
            return StringValidationStatic.IsAlpha(text, allowSpace);
        }

        /// <summary>
        /// Checks if string passed in is a valid AlphaNumeric
        /// </summary>
        /// <param name="text">string containing number to validate</param>
        /// <returns></returns>
        public bool IsAlphaNumeric(string text)
        {
            return StringValidationStatic.IsAlphaNumeric(text);
        }

        /// <summary>
        /// Checks if string passed in is a valid AlphaNumeric
        /// </summary>
        /// <param name="text"></param>
        /// <param name="allowSpace"></param>
        /// <returns></returns>
        /// <remarks>v.2.0.0.12 now supports allowing spaces</remarks>
        public bool IsAlphaNumeric(string text, bool allowSpace)
        {
            return StringValidationStatic.IsAlphaNumeric(text, allowSpace);
        }

        /// <summary>
        /// Checks if string passed in is a valid alphanumeric or a dash
        /// </summary>
        /// <param name="text"></param>
        /// <param name="allowSpace"></param>
        /// <returns></returns>
        public bool IsAlphaNumericOrDash(string text, bool allowSpace)
        {
            return StringValidationStatic.IsAlphaNumericOrDash(text, allowSpace);
        }

        /// <summary>
        /// Checks if string passed in is a valid Alphanumeric (may contain period or space)
        /// </summary>
        /// <param name="text"></param>
        /// <param name="allowSpace"></param>
        /// <returns></returns>
        public bool IsAlphaNumericOrDot(string text, bool allowSpace)
        {
            return StringValidationStatic.IsAlphaNumericOrDot(text, allowSpace);
        }

        /// <summary>
        /// Checks if string passed in is a valid AlphaNumeric (may contain underscore)
        /// </summary>
        /// <param name="text">string containing number to validate</param>
        /// <returns></returns>
        public bool IsAlphaNumericOrUnderscore(string text)
        {
            return StringValidationStatic.IsAlphaNumericOrUnderscore(text);
        }

        /// <summary>
        /// Checks if string passed in is a valid alphanumeric or a dash
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public bool IsAlphaNumericOrUnderscoreOrDash(String text)
        {
            return IsAlphaNumericOrUnderscoreOrDash(text);
        }

        /// <summary>
        /// Checks if string passed in is a valid AlphaNumeric (may contain underscore, period or comma)
        /// </summary>
        /// <param name="text">string containing number to validate</param>
        /// <returns></returns>
        /// <remarks>NEW in v2.0.0.11</remarks>
        public bool IsAlphaNumericOrUnderscoreOrDotOrDashOrComma(string text)
        {
            return StringValidationStatic.IsAlphaNumericOrUnderscoreOrDotOrDashOrComma(text);
        }

        /// <summary>
        /// Checks if string passed in is a valid AlphaNumeric (may contain underscore, period or comma)
        /// </summary>
        /// <param name="text"></param>
        /// <param name="allowSpace"></param>
        /// <returns></returns>
        /// <remarks>v.2.0.0.12 now supports allowing spaces</remarks>
        public bool IsAlphaNumericOrUnderscoreOrDotOrDashOrComma(string text, bool allowSpace)
        {
            return StringValidationStatic.IsAlphaNumericOrUnderscoreOrDotOrDashOrComma(text, allowSpace);
        }

        #endregion
    }
}
