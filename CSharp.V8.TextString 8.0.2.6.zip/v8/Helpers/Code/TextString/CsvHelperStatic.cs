﻿/********************************************************************************
 * CSHARP Text Library - General utility to manipulate text strings
 * 
 * NOTE: Adapted from Clinch.Text
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 *          
 * CHANGES: 
 * 
 *  - (v5.0) All methods converted to static
 *  - (v5.0) Additional code to check parameters passed to exit method quicker
 *  - (v8.0) Upgraded to NET8.0. Created a non-static to call the static functions 
 *				as some clients like Powershell needs non-static. 
 *  
 *  POSSIBLE FUTURE IMPROVEMENTS
 *  
 *  -
 *  
 ********************************************************************************/

namespace CSHARP.V8.Helpers.TextString
{
    using System;
    using System.Collections;
    using System.Text;

    /// <summary>
    /// Assists in working with CSV
    /// </summary>
    public static class CsvHelperStatic
    {
        /// <summary>
        /// Converts a list of objects to CSV
        /// </summary>
        /// <param name="collection">Collection of objects to generate CSV from</param>
        /// <param name="type">type of object being generated</param>
        /// <returns>csv string</returns>
        /// <remarks>
        /// v8.0.1.7 - if the type is string array or dictionary we can write them in the field as delimited lists. 
        /// If they are an object array we can serialize that as JSON
        /// V2.0.0.2 Case Corrected in method name</remarks>
        public static string ConvertToCsv(IEnumerable collection, Type type)
        {
            var stringBuilder = new StringBuilder();
            var header = new StringBuilder();

            // Gets all  properies of the class
            var properties = type.GetProperties();

            // Create CSV header using the classes properties
            foreach (var propertyForHeader in properties) header.Append(propertyForHeader.Name + ",");

            stringBuilder.AppendLine(header.ToString());

            foreach (var objectToGenerateCsvRowFor in collection)
            {
                var body = new StringBuilder();

                // Create new item
                var t1 = objectToGenerateCsvRowFor;
                foreach(var property in properties)
                {
                    var propertyForBody = property.GetValue(t1, null);
                    if (propertyForBody != null)
                    {
                        if ("System.String[]" == property.PropertyType.FullName)
                        {
                            propertyForBody = StringArrayHelperStatic.StringArrayToDelimitedString(propertyForBody as String[], ';');
                        }
                        else if (property.PropertyType.BaseType.FullName.StartsWith("System.Array"))
                        {
                            // This will look at each object in the array 
                            propertyForBody = StringArrayHelperStatic.StringArrayToDelimitedString(propertyForBody as String[], ';');
                        }
                        else if (property.PropertyType.FullName.StartsWith("System.Collections.Generic.Dictionary"))
                        {
                            propertyForBody = StringDictionaryHelperStatic.DictionaryToDelimitedString(propertyForBody as Dictionary<string, string>, ";", "|");
                        }
                        else // Standard system types like System.String or whatever the object takes as .ToString()
                        {
                            // Ensure column values with commas in it are quoted
                            if (propertyForBody.ToString().IndexOf(',') > -1) body.Append("\"" + propertyForBody + "\",");
                            else body.Append(propertyForBody + ",");
                        }
                    }
                    else body.Append(',');
                }

                stringBuilder.AppendLine(body.ToString());
            }
            return stringBuilder.ToString();
        }
    }
}
