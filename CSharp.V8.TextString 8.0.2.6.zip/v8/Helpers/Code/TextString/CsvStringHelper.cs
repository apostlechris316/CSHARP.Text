/********************************************************************************
 * CSHARP Text Library - General utility to manipulate text strings
 * 
 * NOTE: Adapted from Clinch.Text
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 *          
 * CHANGES: 
 * 
 *  - (v5.0) All methods converted to static
 *  - (v5.0) Additional code to check parameters passed to exit method quicker
 *  - (v8.0) Upgraded to NET8.0 
 *  
 *  POSSIBLE FUTURE IMPROVEMENTS
 *  
 *  -
 *  
 ********************************************************************************/

namespace CSHARP.V8.Helpers.TextString
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    /// Assists in cleaning up csv strings
    /// </summary>
    /// <remarks>
    ///	NEW IN v5.0.0.0
    /// </remarks>
    public class CsvStringHelper
	{
		/// <summary>
		/// Returns true if string passed in matches the Base64 RegEx
		/// </summary>
		/// <param name="stringBase64">possible base64 encoded string</param>
		/// <returns></returns>
		/// <remarks>v5.0.0.0 Check if parameter is empty</remarks>
		public string ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(string csvString, string nameOfColumnsToProcess)
        {
            return CsvStringHelperStatic.ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(csvString, nameOfColumnsToProcess);
        }
	}
}
