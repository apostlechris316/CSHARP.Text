/********************************************************************************
 * CSHARP Text Library - General utility to manipulate text strings
 * 
 * NOTE: Adapted from Clinch.Text
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 *          
 * CHANGES: 
 * 
 *  - v8.0.2.0 Moved StringArray specific methods to a separate class 
 *  
 * FUTURE IMPROVEMENTS:
 *  
 *  -
 *  
 ********************************************************************************/

namespace CSHARP.V8.Helpers.TextString
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// General function to help manupulate string arrays
    /// </summary>
    public static class StringArrayHelperStatic
    {
        #region 001 - StringArray To ...

        /// <summary>
        /// Builds a delimited string from a string array. Only include distinct strings
        /// </summary>
        /// <param name="items">array of strings</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        /// <remarks>NEW in 2.0.0.6</remarks>
        public static string StringArrayToDistinctDelimitedString(string[] items, char token)
        {
            var returnValue = new StringBuilder();
            var itemList = new List<string>();
            var firstItem = true;
            foreach (var item in items)
            {
                if (itemList.Contains(item) == false)
                {
                    if (!firstItem) returnValue.Append(token);
                    itemList.Add(item);
                    returnValue.Append(item);
                }
                firstItem = false;
            }
            return returnValue.ToString();
        }

        /// <summary>
        /// Builds a delimited string from a string array
        /// </summary>
        /// <param name="items">array of strings</param>
        /// <param name="token">delimiter</param>
        /// <remarks>NEW IN 8.0.0.4 this version supports string token as well</remarks>
        /// <returns></returns>
        public static string StringArrayToDelimitedString(string[] items, string token)
        {
            var returnValue = new StringBuilder();
            var firstItem = true;
            foreach (var item in items)
            {
                if (!firstItem) returnValue.Append(token);
                returnValue.Append(item);
                firstItem = false;
            }
            return returnValue.ToString();
        }

        /// <summary>
        /// Builds a delimited string from a string array
        /// </summary>
        /// <param name="items">array of strings</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        public static string StringArrayToDelimitedString(string[] items, char token)
        {
            var returnValue = new StringBuilder();
            var firstItem = true;
            foreach (var item in items)
            {
                if (!firstItem) returnValue.Append(token);
                returnValue.Append(item);
                firstItem = false;
            }
            return returnValue.ToString();
        }

        /// <summary>
        /// Builds a string containing a string per line from a delimited string 
        /// </summary>
        /// <param name="items">list of strings</param>
        /// <returns></returns>
        /// <remarks>v8.0.1.1 items parameter changed to string array
        /// NEW in 2.0.0.7</remarks>
        public static string StringArrayToEndOfLineDelimited(string[] items)
        {
            var returnValue = new StringBuilder();
            var firstItem = true;
            foreach (var item in items)
            {
                if (!firstItem) returnValue.Append("\r\n");
                returnValue.Append(item);
                firstItem = false;
            }

            return returnValue.ToString();
        }

        #endregion

        #region 031 Array Validation 

        /// <summary>
        /// If the first and second list are identical including order
        /// </summary>
        /// <param name="first">list of strings to compare</param>
        /// <param name="second">list of string to comare to the first</param>
        /// <returns></returns>
        /// <remarks>v8.0.1.1 first and second parameters changed to string arrays
        /// NEW IN v8.0.0.3</remarks>
        public static bool IsSameArray(string[]? first, string[]? second)
        {
            return IsSameArray(first, second, false);
        }

        /// <summary>
        /// If the first and second array are identical including order
        /// </summary>
        /// <param name="first">string array to compare</param>
        /// <param name="second">string array to compare to the first</param>
        /// <param name="ignoreOrder">if true will sort both lists asc then do the match</param>
        /// <returns></returns>
        /// <remarks>v8.0.1.1 first and second parameters changed to string arrays</remarks>
        public static bool IsSameArray(string[]? first, string[]? second, bool ignoreOrder)
        {
            // if both are null then yes technically same list
            if (first == null && second == null) return true;

            // if only one is null then they are not
            if (first == null || second == null) return false;

            if (first.Length != second.Length) return false;

            var firstAsc = ignoreOrder ? first.OrderBy(x => x).ToArray() : first;
            var secondAsc = ignoreOrder ? second.OrderBy(x => x).ToArray(): second;

            for (int index = 0; index < firstAsc.Length; index++)
            {
                if (firstAsc[index] != secondAsc[index]) return false;
            }

            return true;
        }

        #endregion

        #region Array Manipulation

        /// <summary>
        /// Adds a string to the end of the array
        /// </summary>
        /// <param name="value">Value to add</param>
        /// <returns></returns>
        /// <remarks>NEW IN v8.0.1.4</remarks>
        public static string[] AddStringToArray(string []? stringArray, string value)
        {
            var stringList = stringArray == null ? new List<string>() : stringArray.ToList();
            stringList.Add(value);
            return stringList.ToArray();
        }

        /// <summary>
        /// Adds a string to the end of the array
        /// </summary>
        /// <param name="values">values to add</param>
        /// <returns></returns>
        /// <remarks>NEW IN v8.0.1.4</remarks>
        public static string[] AddStringsToArray(string[]? stringArray, string [] values)
        {
            if (stringArray == null) return values;

            var stringList = stringArray.ToList();
            foreach (var value in values)
            {
                stringList.Add(value);
            }
            return stringList.ToArray();
        }

        /// <summary>
        /// Adds values to the array only if they are missing
        /// </summary>
        /// <param name="stringArray">string array to add the values to</param>
        /// <param name="values">The values to add</param>
        /// <returns></returns>
        public static string[] AddMissingStringsToArray(string[]? stringArray, string [] values)
        {
            if (stringArray == null) return values;

            var stringList = stringArray.ToList();
            foreach (var value in values)
            {
                if(false == stringList.Contains(value)) stringList.Add(value);
            }
            return stringList.ToArray();
        }

        #endregion
    }
}
