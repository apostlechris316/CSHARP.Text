/********************************************************************************
 * CSHARP Text Library - General utility to manipulate text strings
 * 
 * NOTE: Adapted from Clinch.Text
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 *          
 * CHANGES: 
 * 
 *  - (v5.0) All methods converted to static
 *  - (v5.0) Additional code to check parameters passed to exit method quicker
 *  - (v8.0) Upgraded to NET8.0 
 *  
 *  POSSIBLE FUTURE IMPROVEMENTS
 *  
 *  -
 *  
 ********************************************************************************/

namespace CSHARP.V8.Helpers.TextString
{
    using System;
    using System.Text;
    using System.Text.RegularExpressions;

    /// <summary>
	/// Assists in encoding and decoding to and from base 64
	/// </summary>
	/// <remarks> NOTE: Adapted from Clinch.Text
	///		v5.0.0.0 
	///			- class and all its members are now static
	///	</remarks>
	public static class Base64HelperStatic
	{
        /// <summary>
        /// Returns true if string passed in matches the Base64 RegEx
        /// </summary>
        /// <param name="stringBase64">possible base64 encoded string</param>
        /// <returns></returns>
		/// <remarks>v5.0.0.0 Check if parameter is empty</remarks>
		public static bool IsBase64(string stringBase64)
        {
			// empty strings are NOT Base64
			if (string.IsNullOrEmpty(stringBase64)) return false;

            var regEx =
                    "([A-Za-z0-9+/]{4})*" +
                    "([A-Za-z0-9+/]{4}|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{2}==)";

            var matches = Regex.Matches(stringBase64, regEx);
            return matches != null ? matches.Count == 1 : false;
        }

		/// <summary>
		/// Base 64 encoder
		/// </summary>
		/// <param name="toEncode">String to encode in to Base64</param>
		/// <returns>Encoded String</returns>
        /// <remarks>
		///		V2.0.0.2 
		///			- Case Corrected in method name
        ///			- Encoding.ASCII introduced in .NET Standard 1.3
        ///		V8.0.0.0
        ///			- Upgraded to NET8.0
        ///			- Converted to static
        /// </remarks>
		public static string Base64Encode(string toEncode)
		{
			var toEncodeAsBytes = Encoding.ASCII.GetBytes(toEncode);
			return Convert.ToBase64String(toEncodeAsBytes);
		}
		/// <summary>
		/// Base 64 decoder
		/// </summary>
		/// <param name="data">Base64 data to decode</param>
		/// <returns>Decoded String</returns>
		/// <remarks>
		///		v5.0.0.0 - Check if parameter is empty
		///		v8.0.0.0 
		///			- Upgraded to net8.0
		///			- Converted to static	
		///
		///</remarks>
		public static string Base64Decode(string data)
		{
			// if string is empty then just return it no need to decode it
			if (string.IsNullOrEmpty(data)) return String.Empty;

			string result2;
			try
			{
				var encoder = new UTF8Encoding();
				var utf8Decode = encoder.GetDecoder();
				var todecodeByte = Convert.FromBase64String(data);
				var charCount = utf8Decode.GetCharCount(todecodeByte, 0, todecodeByte.Length);
				var decodedChar = new char[charCount];
				utf8Decode.GetChars(todecodeByte, 0, todecodeByte.Length, decodedChar, 0);
				var result = new string(decodedChar);
				result2 = result;
			}
			catch (Exception e)
			{
				throw new Exception("Error in base64Decode" + e.Message);
			}
			return result2;
		}
	}
}
