/********************************************************************************
 * CSHARP Text Library - General utility to manipulate text strings
 * 
 * NOTE: Adapted from Clinch.Text
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 *          
 * CHANGES: 
 * 
 *  - (v5.0) All methods converted to static
 *  - (v5.0) Additional code to check parameters passed to exit method quicker
 *  - (v8.0) Upgraded to NET8.0. Created a non-static to call the static functions 
 *				as some clients like Powershell needs non-static. 
 *  
 *  POSSIBLE FUTURE IMPROVEMENTS
 *  
 *  -
 *  
 ********************************************************************************/

namespace CSHARP.V8.Helpers.TextString
{
    /// <summary>
	/// Assists in encoding and decoding to and from base 64
	/// </summary>
	/// <remarks> NOTE: Adapted from Clinch.Text
	///		v5.0.0.0 
	///			- class and all its members are now static
	///	</remarks>
	public class Base64Helper
	{
        /// <summary>
        /// Returns true if string passed in matches the Base64 RegEx
        /// </summary>
        /// <param name="stringBase64">possible base64 encoded string</param>
        /// <returns></returns>
		/// <remarks>
		///		v5.0.0.0 - Check if parameter is empty
		///		v8.0.0.0 - Non-static calls static version
		/// </remarks>
		public bool IsBase64(string stringBase64)
        {
			return Base64HelperStatic.IsBase64(stringBase64);
        }

		/// <summary>
		/// Base 64 encoder
		/// </summary>
		/// <param name="toEncode">String to encode in to Base64</param>
		/// <returns>Encoded String</returns>
        /// <remarks>
		///		V2.0.0.2 
		///			- Case Corrected in method name
        ///			- Encoding.ASCII introduced in .NET Standard 1.3
        ///		V8.0.0.0
        ///			- Upgraded to NET8.0
        ///			- non-static calls static version
        /// </remarks>
		public string Base64Encode(string toEncode)
		{
			return Base64HelperStatic.Base64Encode(toEncode);
		}
        /// <summary>
        /// Base 64 decoder
        /// </summary>
        /// <param name="data">Base64 data to decode</param>
        /// <returns>Decoded String</returns>
        /// <remarks>
        ///		v5.0.0.0 - Check if parameter is empty
        ///		v8.0.0.0 
        ///			- Upgraded to net8.0
        ///			- non-static calls static version
        ///</remarks>
        public string Base64Decode(string data)
		{
			return Base64HelperStatic.Base64Decode(data);
		}
	}
}
