/********************************************************************************
 * CSHARP Text Library - General utility to manipulate text strings
 * 
 * NOTE: Adapted from Clinch.Text
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 *          
 * CHANGES: 
 * 
 *  - (v5.0) All methods converted to static
 *  - (v5.0) Additional code to check parameters passed to exit method quicker
 *  - (v8.0) Upgraded to NET8.0 
 *  
 * FUTURE IMPROVEMENTS:
 *  
 *  -
 *  
 ********************************************************************************/

namespace CSHARP.V8.Helpers.TextString
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// General function to help manupulate strings
    /// </summary>
    public static class StringListHelperStatic
    {
        #region 009 - StringList To ...

        /// <summary>
        /// Builds a delimited string from a list of strings
        /// </summary>
        /// <param name="items">list of strings</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        /// <remarks> v8.0.1.1 items parameter changed to string array
        /// NEW IN v5.0.0.0. This version allows you to pass a string for a token to support multi-character tokens eg. || </remarks>
        public static string StringListToDelimitedString(List<string> items, char token)
        {
            var returnValue = new StringBuilder();
            var firstItem = true;
            foreach (var item in items)
            {
                if (!firstItem) returnValue.Append(token);
                returnValue.Append(item);
                firstItem = false;
            }
            return returnValue.ToString();
        }

        /// <summary>
        /// Builds a delimited string from a list of strings
        /// </summary>
        /// <param name="items">list of strings</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        /// <remarks> v8.0.1.1 items parameter changed to string array
        /// NEW IN v5.0.0.0. This version allows you to pass a string for a token to support multi-character tokens eg. || </remarks>
        public static string StringListToDelimitedString(List<string> items, string token)
        {
            var returnValue = new StringBuilder();
            var firstItem = true;
            foreach (var item in items)
            {
                if (!firstItem) returnValue.Append(token);
                returnValue.Append(item);
                firstItem = false;
            }
            return returnValue.ToString();
        }

        /// <summary>
        /// Builds a string containing a string per line from a delimited string 
        /// </summary>
        /// <param name="items">list of strings</param>
        /// <returns></returns>
        /// <remarks>v8.0.1.1 items parameter changed to string array
        /// NEW in 2.0.0.7</remarks>
        public static string StringListToEndOfLineDelimited(List<string> items)
        {
            var returnValue = new StringBuilder();
            var firstItem = true;
            foreach (var item in items)
            {
                if (!firstItem) returnValue.Append("\r\n");
                returnValue.Append(item);
                firstItem = false;
            }

            return returnValue.ToString();
        }

        #endregion

        #region 030 List Validation

        /// <summary>
        /// If the first and second list are identical including order
        /// </summary>
        /// <param name="first">list of strings to compare</param>
        /// <param name="second">list of string to comare to the first</param>
        /// <returns></returns>
        /// <remarks>v8.0.1.9 allow nulls to be passed and w do the check
        /// NEW IN v8.0.0.3</remarks>
        public static bool IsSameList(List<string>? first, List<string>? second)
        {
            return IsSameList(first, second, false);
        }

        /// <summary>
        /// If the first and second list are identical including order
        /// </summary>
        /// <param name="first">string array to compare</param>
        /// <param name="second">string array to compare to the first</param>
        /// <param name="ignoreOrder">if true will sort both lists asc then do the match</param>
        /// <returns></returns>
        /// <remarks>v8.0.1.1 first and second parameters changed to string arrays</remarks>
        public static bool IsSameList(List<string>? first, List<string>? second, bool ignoreOrder)
        {
            // if both are null then yes technically same list
            if (first == null && second == null) return true;

            // if only one is null then they are not
            if (first == null || second == null) return false;

            if (first.Count != second.Count) return false;

            var firstAsc = ignoreOrder ? first.OrderBy(x => x).ToList() : first;
            var secondAsc = ignoreOrder ? second.OrderBy(x => x).ToList() : second;

            for (int index = 0; index < firstAsc.Count; index++)
            {
                if (firstAsc[index] != secondAsc[index]) return false;
            }

            return true;
        }

        #endregion

        #region List Manipulation

        #endregion
    }
}
