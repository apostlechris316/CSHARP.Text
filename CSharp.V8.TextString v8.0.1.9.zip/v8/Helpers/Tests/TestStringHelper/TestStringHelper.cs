
namespace TestStringHelper
{
    using CSHARP.V8.Helpers.TextString;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;

    [TestClass]
    public class TestStringHelper
    {
        #region 001 Regex Tests

        /// <summary>
        /// Test getting email addresses from test string
        /// </summary>
        [TestMethod]
        public void Test_001_001_GetAllMatches_EmailAddresses()
        {
            var testString = "mailto:chris.williams@readwatchcreate.com;chrisw_88@hotmail.com";
            var results = StringHelperStatic.GetAllMatches(testString, StringHelper.EmailAddressRegex);
            Assert.IsNotNull(results);
            Assert.IsTrue(results.Length == 2);
            Assert.IsTrue(results[0] == "chris.williams@readwatchcreate.com");
            Assert.IsTrue(results[1] == "chrisw_88@hotmail.com");

            StringHelper stringHelper = new StringHelper();
            results = stringHelper.GetAllMatches(testString, StringHelper.EmailAddressRegex);
            Assert.IsNotNull(results);
            Assert.IsTrue(results.Length == 2);
            Assert.IsTrue(results[0] == "chris.williams@readwatchcreate.com");
            Assert.IsTrue(results[1] == "chrisw_88@hotmail.com");

        }

        /// <summary>
        /// Test getting email addresses from test string
        /// </summary>
        /// <remarks>We Need To Find the AllPhoneRegex</remarks>
//        [TestMethod]
        public void Test_001_002_GetAllMatches_PhoneNumbers()
        {
            //var testString = "tel:1 905-220-8496, (905)320-3428";
            //var results = StringHelper.GetAllMatches(testString, StringHelper.AllPhoneRegex);
            //Assert.IsNotNull(results);
            //Assert.IsTrue(results.Count == 2);
            //Assert.IsTrue(results[0] == "905-220-8496");
            //Assert.IsTrue(results[1] == "(905)3203428");
        }

        #endregion

        #region 002 - ConvertToAlphaNumeric

        /// <summary>
        /// Test getting brace block from test string with various test string
        /// </summary>
        [TestMethod]
        public void Test_002_002_GetEverythingBetweenBraces_TestStrings()
        {
            // TO DO: Need to grab the test from elsewhere and bring them over
            #region Test public static string ConvertToAlphaNumeric(string toConvert, bool removeWhiteSpace) 

            // Test with an empty string
            Assert.IsTrue(POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = false", string.Empty, string.Empty, false));
            Assert.IsTrue(POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = true", string.Empty, string.Empty, true));

            // Test with whitespace characters
            Assert.IsTrue(POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - '\t12 34\t', RemoveWhiteSpace = false", "\t12 34\t", "\t12 34\t", false));
            Assert.IsTrue(POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - '\t12 34\t', RemoveWhiteSpace = true", "1234", "\t12 34\t", false));

            #endregion

            #region Test public static string ConvertToAlphaNumeric(string toConvert, bool removeWhiteSpace, bool removeUnderScore) 

            // Test with an empty string
            Assert.IsTrue(POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = false, removeUnderScore = false", string.Empty, string.Empty, false, false));
            Assert.IsTrue(POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = false, removeUnderScore = true", string.Empty, string.Empty, false, true));
            Assert.IsTrue(POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = true, removeUnderScore = false", string.Empty, string.Empty, true, false));
            Assert.IsTrue(POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = true, removeUnderScore = true", string.Empty, string.Empty, false, true));

            // Testd with whitespace characters but no underscores
            Assert.IsTrue(POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = false, removeUnderScore = false", "\t12 34\t", "\t12 34\t", false, false));
            Assert.IsTrue(POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = false, removeUnderScore = true", "\t12 34\t", "\t12 34\t", false, true));
            Assert.IsTrue(POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = true, removeUnderScore = false", "\t12 34\t", "1234", true, false));
            Assert.IsTrue(POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = true, removeUnderScore = true", "\t12 34\t", "1234", true, true));

            // Test with whitespace and underscore characters
            Assert.IsTrue(POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = false, removeUnderScore = false", "\t12_ _34\t", "\t12_ _34\t", false, false));
            Assert.IsTrue(POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = false, removeUnderScore = true", "\t12_ _34\t", "\t12 34\t", false, true));
            Assert.IsTrue(POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = true, removeUnderScore = false", "\t12_ _34\t", "12__34", true, false));
            Assert.IsTrue(POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = true, removeUnderScore = true", "\t12_ _34\t", "1234", true, true));

            #endregion
        }

        /// <summary>
        /// Runs a positive test on ConvertToAlphaNumeric
        /// </summary>
        /// <param name="failMessage">message to display on failure</param>
        /// <param name="expectedResult">result we expect</param>
        /// <param name="toConvert">string to convert</param>
        /// <param name="removeWhiteSpace">If true, removes tabs and white spaces</param>
        /// <returns></returns>
        public static bool POSITIVE_TEST_ConvertToAlplaNumeric(string failMessage, string expectedResult, string toConvert, bool removeWhiteSpace)
        {
            // Declare helper classes
            var stringHelper = new StringHelper();

            var result = StringHelperStatic.ConvertToAlphaNumeric(toConvert, false);
            if (result != expectedResult)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Runs a positive test on ConvertToAlphaNumeric
        /// </summary>
        /// <param name="failMessage">message to display on failure</param>
        /// <param name="expectedResult">result we expect</param>
        /// <param name="toConvert">string to convert</param>
        /// <param name="removeWhiteSpace">If true, removes tabs and white spaces</param>
        /// <param name="removeUnderScore">If true, removes _ as well</param>
        /// <returns></returns>
        public static bool POSITIVE_TEST_ConvertToAlplaNumeric(string failMessage, string expectedResult, string toConvert, bool removeWhiteSpace, bool removeUnderScore)
        {
            // Declare helper classes
            var stringHelper = new StringHelper();

            var result = StringHelperStatic.ConvertToAlphaNumeric(toConvert, removeWhiteSpace, removeUnderScore);
            if (result != expectedResult)
            {
                return false;
            }

            return true;
        }

        #endregion

        #region 028 Test GetEverythingBetweenBraces

        /// <summary>
        /// Test getting brace block from test string with empty string
        /// </summary>
        [TestMethod]
        public void Test_028_001_GetEverythingBetweenBraces_EmptyString()
        {
            // ******************************************************************
            // Empty String Test
            // ******************************************************************

            var testString = string.Empty;
            var stringToProcess = testString;

            var results = StringHelperStatic.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(string.IsNullOrEmpty(results));
            Assert.IsTrue(stringToProcess == testString);

            StringHelper stringHelper = new StringHelper();
            results = stringHelper.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(string.IsNullOrEmpty(results));
            Assert.IsTrue(stringToProcess == testString);
        }

        /// <summary>
        /// Test getting brace block from test string with various test string
        /// </summary>
        [TestMethod]
        public void Test_028_002_GetEverythingBetweenBraces_TestStrings()
        {
            StringHelper stringHelper = new StringHelper();

            // ******************************************************************
            // No Braces In Test String
            // ******************************************************************

            var testString = "This is a string without braces";
            var stringToProcess = testString;

            var results = StringHelperStatic.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(string.IsNullOrEmpty(results));
            Assert.IsTrue(stringToProcess == testString);

            results = stringHelper.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(string.IsNullOrEmpty(results));
            Assert.IsTrue(stringToProcess == testString);

            // ******************************************************************
            // Braces not at start of string
            // ******************************************************************

            testString = " { This is a string with braces }";
            stringToProcess = testString;

            Assert.ThrowsException<ArgumentException>(() => StringHelperStatic.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess));
            Assert.ThrowsException<ArgumentException>(() => stringHelper.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess));

            // ******************************************************************
            // One Set Of Braces In Test String nothing else
            // ******************************************************************

            testString = "{ This is a string with braces }";
            stringToProcess = testString;

            results = StringHelperStatic.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == testString);
            Assert.IsTrue(string.IsNullOrEmpty(stringToProcess));

            stringToProcess = testString;
            results = stringHelper.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == testString);
            Assert.IsTrue(string.IsNullOrEmpty(stringToProcess));

            // ******************************************************************
            // One Set Of Braces In Test String with text after
            // ******************************************************************

            testString = "{ This is a string with braces } There is more text here";
            stringToProcess = testString;

            results = StringHelperStatic.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == "{ This is a string with braces }");
            Assert.IsTrue(stringToProcess == " There is more text here");

            stringToProcess = testString;
            results = stringHelper.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == "{ This is a string with braces }");
            Assert.IsTrue(stringToProcess == " There is more text here");

            // ******************************************************************
            // Braces Nested One Deep In Test String nothing else
            // ******************************************************************

            // Test 1:
            testString = "{ This is a string with braces { There is a nested one } }";
            stringToProcess = testString;

            results = StringHelperStatic.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == testString);
            Assert.IsTrue(string.IsNullOrEmpty(stringToProcess));

            stringToProcess = testString;
            results = stringHelper.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == testString);
            Assert.IsTrue(string.IsNullOrEmpty(stringToProcess));

            // Test 2:
            testString = "{ This is a string with braces { There is a nested one } There is more text in the first brace }";
            stringToProcess = testString;

            results = StringHelperStatic.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == testString);
            Assert.IsTrue(string.IsNullOrEmpty(stringToProcess));

            stringToProcess = testString;
            results = stringHelper.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == testString);
            Assert.IsTrue(string.IsNullOrEmpty(stringToProcess));

            // ******************************************************************
            // Braces Nested One Deep In Test String with text after braces
            // ******************************************************************

            // Test 1:
            testString = "{ This is a string without braces { There is a nested one } } There is more text here";
            stringToProcess = testString;

            results = StringHelperStatic.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == "{ This is a string without braces { There is a nested one } }");
            Assert.IsTrue(stringToProcess == " There is more text here");

            stringToProcess = testString;
            results = stringHelper.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == "{ This is a string without braces { There is a nested one } }");
            Assert.IsTrue(stringToProcess == " There is more text here");

            // Test 2:
            testString = "{ This is a string without braces { There is a nested one } There is more text in the first brace } There is more text here";
            stringToProcess = testString;

            results = StringHelperStatic.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == "{ This is a string without braces { There is a nested one } There is more text in the first brace }");
            Assert.IsTrue(stringToProcess == " There is more text here");

            stringToProcess = testString;
            results = stringHelper.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == "{ This is a string without braces { There is a nested one } There is more text in the first brace }");
            Assert.IsTrue(stringToProcess == " There is more text here");

            // ******************************************************************
            // Braces Nested One Deep but missing end
            // ******************************************************************

            // Test 1:
            testString = "{ A1 { B1 { C1 } } There is more text here";
            stringToProcess = testString;
            Assert.ThrowsException<Exception>(() => StringHelperStatic.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess));
            Assert.ThrowsException<Exception>(() => stringHelper.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess));

            // Test 2: 
            testString = "{ A1 { B1 } { C1 } There is more text here";
            stringToProcess = testString;
            Assert.ThrowsException<Exception>(() => StringHelperStatic.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess));
            Assert.ThrowsException<Exception>(() => stringHelper.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess));

            // ******************************************************************
            // Braces Nested Two Deep In Test String nothing else
            // ******************************************************************

            // Test 1:
            testString = "{ This is a string without braces { There is a nested one { and another one} more text here } }";
            stringToProcess = testString;

            results = StringHelperStatic.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == testString);
            Assert.IsTrue(string.IsNullOrEmpty(stringToProcess));

            stringToProcess = testString;
            results = stringHelper.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == testString);
            Assert.IsTrue(string.IsNullOrEmpty(stringToProcess));

            // Test 2:
            testString = "{ This is a string without braces { There is a nested one } There is more text in the first brace }";
            stringToProcess = testString;

            results = StringHelperStatic.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == testString);
            Assert.IsTrue(string.IsNullOrEmpty(stringToProcess));

            stringToProcess = testString;
            results = stringHelper.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == testString);
            Assert.IsTrue(string.IsNullOrEmpty(stringToProcess));

            // ******************************************************************
            // Braces Nested Two Deep In Test String with text after braces
            // ******************************************************************

            // Test 1:
            testString = "{ This is a string without braces { There is a nested one { and another one} more text here } } There is more text here";
            stringToProcess = testString;

            results = StringHelperStatic.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == "{ This is a string without braces { There is a nested one { and another one} more text here } }");
            Assert.IsTrue(stringToProcess == " There is more text here");

            stringToProcess = testString;
            results = stringHelper.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == "{ This is a string without braces { There is a nested one { and another one} more text here } }");
            Assert.IsTrue(stringToProcess == " There is more text here");

            // Test 2:
            testString = "{ This is a string without braces { There is a nested one } There is more text in the first brace } There is more text here";
            stringToProcess = testString;

            results = StringHelperStatic.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == "{ This is a string without braces { There is a nested one } There is more text in the first brace }");
            Assert.IsTrue(stringToProcess == " There is more text here");

            stringToProcess = testString;
            results = stringHelper.GetEverythingBetweenBraces(stringToProcess, true, out stringToProcess);
            Assert.IsTrue(results == "{ This is a string without braces { There is a nested one } There is more text in the first brace }");
            Assert.IsTrue(stringToProcess == " There is more text here");
        }

        #endregion

/*
        #region Negative Testing - Things we expect to fail  

            //try { var expectedFailure = googleDriveManager.CreateGoogleSheet(null, string.Empty, string.Empty, null); }
            //catch (Exception exception)
            //{
            //    Console.WriteLine("******* STEP 1.1.1 - PASSED : EXPECTED FAILURE with no drive service passed: ");
            //    Console.WriteLine(exception.ToString());
            //    Console.WriteLine("*******");
            //    Console.ReadKey();
            //}

            #endregion

            #region Positive Testing Things we expect to work

            #region Test public static string ConvertToAlphaNumeric(string toConvert, bool removeWhiteSpace) 

            // Test with an empty string
            if (POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = false", string.Empty, string.Empty, false) == false)
                return;
            if (POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = true", string.Empty, string.Empty, true) == false)
                return;

            // Test with whitespace characters
            if (POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - '\t12 34\t', RemoveWhiteSpace = false", "\t12 34\t", "\t12 34\t", false) == false)
                return;
            if (POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - '\t12 34\t', RemoveWhiteSpace = true", "1234", "\t12 34\t", false) == false)
                return;

            #endregion

            #region Test public static string ConvertToAlphaNumeric(string toConvert, bool removeWhiteSpace, bool removeUnderScore) 

            // Test with an empty string
            if (POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = false, removeUnderScore = false", string.Empty, string.Empty, false, false) == false)
                return;
            if (POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = false, removeUnderScore = true", string.Empty, string.Empty, false, true) == false)
                return;
            if (POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = true, removeUnderScore = false", string.Empty, string.Empty, true, false) == false)
                return;
            if (POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = true, removeUnderScore = true", string.Empty, string.Empty, false, true) == false)
                return;

            // Testd with whitespace characters but no underscores
            if (POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = false, removeUnderScore = false", "\t12 34\t", "\t12 34\t", false, false) == false)
                return;
            if (POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = false, removeUnderScore = true", "\t12 34\t", "\t12 34\t", false, true) == false)
                return;
            if (POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = true, removeUnderScore = false", "\t12 34\t", "1234", true, false) == false)
                return;
            if (POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = true, removeUnderScore = true", "\t12 34\t", "1234", true, true) == false)
                return;

            // Test with whitespace and underscore characters
            if (POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = false, removeUnderScore = false", "\t12_ _34\t", "\t12_ _34\t", false, false) == false)
                return;
            if (POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = false, removeUnderScore = true", "\t12_ _34\t", "\t12 34\t", false, true) == false)
                return;
            if (POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = true, removeUnderScore = false", "\t12_ _34\t", "12__34", true, false) == false)
                return;
            if (POSITIVE_TEST_ConvertToAlplaNumeric("ConvertToAlphaNumeric - string.Empty, RemoveWhiteSpace = true, removeUnderScore = true", "\t12_ _34\t", "1234", true, true) == false)
                return;

            #endregion

*/
    }
}