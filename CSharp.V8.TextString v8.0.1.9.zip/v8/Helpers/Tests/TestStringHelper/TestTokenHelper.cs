
namespace TestTemplates
{
    using CSHARP.V8.Helpers.TextString;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;
    using System.Collections.Generic;

    [TestClass]
    public class TestTokenHelper
    {
        #region 001 - FindAllTokensInItem 

        [TestMethod]
        public void Test_001_001_FindAllTokensInItem_Empty()
        {
            Assert.ThrowsException<ArgumentNullException>(() => TokenHelperStatic.FindAllTokensInItem(string.Empty, string.Empty));
        }

        [TestMethod]
        public void Test_001_002_FindAllTokensInItem_ProperTest()
        {
            string itemToCheck = "This has a [[TOKEN_1]] and another ((TOKEN_2)) and again {{TOKEN_3}}. Then same but [TOKEN_4] and another (TOKEN_5) and again {TOKEN_6}";
            string brokenTokenWrapper = "[STROKEN]";
            string tokenWrapperWrongOrder = "[TOKEN],(TOKEN),{TOKEN},[[TOKEN]],((TOKEN)),{{TOKEN}}";
            string tokenWrapperCorrectOrder = "[[TOKEN]],((TOKEN)),{{TOKEN}},[TOKEN],(TOKEN),{TOKEN}";

            Assert.ThrowsException<ArgumentException>(() => TokenHelperStatic.FindAllTokensInItem(brokenTokenWrapper, itemToCheck));

            var tokens = TokenHelperStatic.FindAllTokensInItem(tokenWrapperWrongOrder, itemToCheck);

            // NOTE: BROKEN ORDER WE LOSE THE END ]
            Assert.IsTrue(tokens[0] == "[[TOKEN_1]");
            // THIS ONE IS CORRECT
            Assert.IsTrue(tokens[1] == "[TOKEN_4]");
            // NOTE: BROKEN ORDER WE LOSE THE END )
            Assert.IsTrue(tokens[2] == "((TOKEN_2)");
            // THIS ONE IS CORRECT
            Assert.IsTrue(tokens[3] == "(TOKEN_5)");
            // NOTE: BROKEN ORDER WE LOSE THE END }
            Assert.IsTrue(tokens[4] == "{{TOKEN_3}");
            // THIS ONE IS CORRECT
            Assert.IsTrue(tokens[5] == "{TOKEN_6}");

            tokens = TokenHelperStatic.FindAllTokensInItem(tokenWrapperCorrectOrder, itemToCheck);

            foreach (var token in tokens)
            {
                // Note how they are all correct
                Assert.IsTrue(tokens[0] == "[[TOKEN_1]]");
                Assert.IsTrue(tokens[1] == "((TOKEN_2))");
                Assert.IsTrue(tokens[2] == "{{TOKEN_3}}");
                Assert.IsTrue(tokens[3] == "[TOKEN_4]");
                Assert.IsTrue(tokens[4] == "(TOKEN_5)");
                Assert.IsTrue(tokens[5] == "{TOKEN_6}");
            }
        }

        #endregion

        #region 002 - MergeTokens

        [TestMethod]
        public void Test_002_001_MergeTokens_Empty()
        {
            var tokens = new Dictionary<string, string>();

            // Let's make it fail with nulls
            Assert.ThrowsException<ArgumentNullException>(() => TokenHelperStatic.MergeTokens(string.Empty, null));
            Assert.ThrowsException<ArgumentNullException>(() => TokenHelperStatic.MergeTokens("some string", null));
            Assert.ThrowsException<ArgumentNullException>(() => TokenHelperStatic.MergeTokens(string.Empty, new Dictionary<string, string>()));
            tokens.Add("{INSERT_NAME_HERE}", "Christopher Thomas Williams");
            Assert.ThrowsException<ArgumentNullException>(() => TokenHelperStatic.MergeTokens(string.Empty, tokens));
        }

        [TestMethod]
        public void Test_002_002_MergeTokens_VariousTestIncludingNesting()
        {
            // Test With Tokens
            var tokens = new Dictionary<string, string>();
            tokens.Add("{INSERT_NAME_HERE}", "Christopher Thomas Williams");
            string toReplace = "My name is {INSERT_NAME_HERE}";
            Assert.IsTrue(TokenHelperStatic.MergeTokens(toReplace, tokens) == "My name is Christopher Thomas Williams");

            tokens = new Dictionary<string, string>();
            tokens.Add("{INSERT_NAME_HERE}", "Christopher Thomas Williams");
            toReplace = "My name is {INSERT_NAME_HERE}. Yes my name is {INSERT_NAME_HERE}";
            Assert.IsTrue(TokenHelperStatic.MergeTokens(toReplace, tokens) == "My name is Christopher Thomas Williams. Yes my name is Christopher Thomas Williams");

            tokens = new Dictionary<string, string>();
            tokens.Add("{INSERT_NAME_HERE}", "Christopher Thomas Williams");
            tokens.Add("{FIELD_NAME}", "NAME");
            toReplace = "My name is {INSERT_NAME_HERE}. Yes my name is {INSERT_{FIELD_NAME}_HERE}";
            Assert.IsTrue(TokenHelperStatic.MergeTokens(toReplace, tokens) == "My name is Christopher Thomas Williams. Yes my name is Christopher Thomas Williams");

            tokens = new Dictionary<string, string>();
            tokens.Add("{INSERT_NAME_HERE}", "Christopher Thomas Williams");
            tokens.Add("{FIELD_NAME}", "NAME");
            tokens.Add("{FIELD}", "NAME");
            toReplace = "My name is {INSERT_NAME_HERE}. Yes my name is {INSERT_{FIELD_{FIELD}}_HERE}";
            Assert.IsTrue(TokenHelperStatic.MergeTokens(toReplace, tokens) == "My name is Christopher Thomas Williams. Yes my name is Christopher Thomas Williams");
        }


        [TestMethod]
        public void Test_002_003_SmartMergeTokens_VariousTestIncludingNesting()
        {
            // Test With Tokens
            var tokens = new Dictionary<string, string>();
            tokens.Add("{INSERT_NAME_HERE}", "Christopher Thomas Williams");
            string toReplace = "My name is {INSERT_NAME_HERE}";
            Assert.IsTrue(TokenHelperStatic.SmartMergeTokens("{TOKEN}",toReplace, tokens) == "My name is Christopher Thomas Williams");
            
            tokens = new Dictionary<string, string>();
            tokens.Add("{INSERT_NAME_HERE}", "Christopher Thomas Williams");
            toReplace = "My name is {INSERT_NAME_HERE}. Yes my name is {INSERT_NAME_HERE}";
            Assert.IsTrue(TokenHelperStatic.SmartMergeTokens("{TOKEN}", toReplace, tokens) == "My name is Christopher Thomas Williams. Yes my name is Christopher Thomas Williams");

            tokens = new Dictionary<string, string>();
            tokens.Add("{FIELD_NAME}", "NAME");
            tokens.Add("{INSERT_NAME_HERE}", "Christopher Thomas Williams");
            toReplace = "My name is {INSERT_NAME_HERE}. Yes my name is {INSERT_{FIELD_NAME}_HERE}";
            Assert.IsTrue(TokenHelperStatic.SmartMergeTokens("{TOKEN}", toReplace, tokens) == "My name is Christopher Thomas Williams. Yes my name is Christopher Thomas Williams");

            tokens = new Dictionary<string, string>();
            tokens.Add("{FIELD}", "NAME");
            tokens.Add("{FIELD_NAME}", "NAME");
            tokens.Add("{INSERT_NAME_HERE}", "Christopher Thomas Williams");
            toReplace = "My name is {INSERT_NAME_HERE}. Yes my name is {INSERT_{FIELD_{FIELD}}_HERE}";
            Assert.IsTrue(TokenHelperStatic.SmartMergeTokens("{TOKEN}", toReplace, tokens) == "My name is Christopher Thomas Williams. Yes my name is Christopher Thomas Williams");

            // Test With special tokens in contents

            // CHECK 1: Proper case
            tokens = new Dictionary<string, string>();
            tokens.Add("{FIELD}", "NAME");
            tokens.Add("{FIELD_NAME}", "NAME");
            tokens.Add("{INSERT_NAME_HERE}", "christopher thomas williams");
            toReplace = "My name is {INSERT_NAME_HERE:PROPER}. Yes my name is {INSERT_{FIELD_{FIELD}}_HERE:PROPER}";
            Assert.IsTrue(TokenHelperStatic.SmartMergeTokens("{TOKEN}", toReplace, tokens) == "My name is Christopher Thomas Williams. Yes my name is Christopher Thomas Williams");

            // CHECK 2: Upper case
            tokens = new Dictionary<string, string>();
            tokens.Add("{FIELD}", "NAME");
            tokens.Add("{FIELD_NAME}", "NAME");
            tokens.Add("{INSERT_NAME_HERE}", "christopher thomas williams");
            toReplace = "My name is {INSERT_NAME_HERE:UPPER}. Yes my name is {INSERT_{FIELD_{FIELD}}_HERE:UPPER}";
            Assert.IsTrue(TokenHelperStatic.SmartMergeTokens("{TOKEN}", toReplace, tokens) == "My name is CHRISTOPHER THOMAS WILLIAMS. Yes my name is CHRISTOPHER THOMAS WILLIAMS");

            // CHECK 3: Lower case
            tokens = new Dictionary<string, string>();
            tokens.Add("{FIELD}", "NAME");
            tokens.Add("{FIELD_NAME}", "NAME");
            tokens.Add("{INSERT_NAME_HERE}", "Christopher Thomas Williams");
            toReplace = "My name is {INSERT_NAME_HERE:LOWER}. Yes my name is {INSERT_{FIELD_{FIELD}}_HERE:LOWER}";
            Assert.IsTrue(TokenHelperStatic.SmartMergeTokens("{TOKEN}", toReplace, tokens) == "My name is christopher thomas williams. Yes my name is christopher thomas williams");

            // CHECK 4: Proper case, Upper case and Lower all in one string
            tokens = new Dictionary<string, string>();
            tokens.Add("{FIELD}", "NAME");
            tokens.Add("{FIELD_NAME}", "NAME");
            tokens.Add("{INSERT_NAME_HERE}", "Christopher THOMAS williams");
            toReplace = "My name is {INSERT_NAME_HERE:PROPER}. Yes my name is {INSERT_{FIELD_{FIELD}}_HERE} and here it is in UPPER: {INSERT_NAME_HERE:UPPER} and in LOWER: {INSERT_NAME_HERE:LOWER}";
            var expectedResult = "My name is Christopher Thomas Williams. Yes my name is Christopher THOMAS williams and here it is in UPPER: CHRISTOPHER THOMAS WILLIAMS and in LOWER: christopher thomas williams";
            Assert.IsTrue(TokenHelperStatic.SmartMergeTokens("{TOKEN}", toReplace, tokens) == expectedResult);
        }



        #endregion

        #region 003 - MergeTokensInFile - TO DO: Implement tests

        #endregion

        #region 004 - MergeTokensInFiles

        [TestMethod]
        public void Test_001_020_MergeTokensInFiles_ProperTest()
        {
            Dictionary<string, string> tokens = new Dictionary<string, string>();

            // Continents
            tokens.Add("NER_MAPS_STATIC_GRAMMAR_BLOCK_CONTINENT_MAP_", "CONTINENT_");
            tokens.Add("NER_MAPS_STATIC_WORD_CONTINENT_MAP_", "CONTINENT_");
            tokens.Add("CONTINENT_MAP_", "CONTINENT_");

            string itemFolder = @"C:\af\2024\Libraries\NerEngine\v8\Data\Initialization\ner\Geography\Continents\GrammarBlock";
            string itemFilePattern = @"continent_*.json";
            var results = TokenHelperStatic.MergeTokensInFiles(itemFolder, itemFilePattern, tokens);
            itemFilePattern = @"NER_MAPS_STATIC_GRAMMAR_BLOCK_CONTINENT_MAP_*.json";
            results = TokenHelperStatic.MergeTokensInFiles(itemFolder, itemFilePattern, tokens);

            itemFolder = @"C:\af\2024\Libraries\NerEngine\v8\Data\Initialization\ner\Geography\Continents\Word";
            itemFilePattern = @"continent_*.json";
            results = TokenHelperStatic.MergeTokensInFiles(itemFolder, itemFilePattern, tokens);
            itemFilePattern = @"NER_MAPS_STATIC_WORD_CONTINENT_MAP_*.json";
            results = TokenHelperStatic.MergeTokensInFiles(itemFolder, itemFilePattern, tokens);

            // Country
            tokens.Add("NER_MAPS_STATIC_GRAMMAR_BLOCK_COUNTRY_MAP_3_", "COUNTRY_");
            tokens.Add("NER_MAPS_STATIC_WORD_COUNTRY_MAP_3_", "COUNTRY_");
            tokens.Add("COUNTRY_MAP_3_", "COUNTRY_");

            itemFolder = @"C:\af\2024\Libraries\NerEngine\v8\Data\Initialization\ner\Geography\Countries\GrammarBlock";
            itemFilePattern = @"COUNTRY_MAP_3_*.json";
            results = TokenHelperStatic.MergeTokensInFiles(itemFolder, itemFilePattern, tokens);
            itemFilePattern = @"NER_MAPS_STATIC_GRAMMAR_BLOCK_COUNTRY_MAP_3_*.json";
            results = TokenHelperStatic.MergeTokensInFiles(itemFolder, itemFilePattern, tokens);

            itemFolder = @"C:\af\2024\Libraries\NerEngine\v8\Data\Initialization\ner\Geography\Countries\word";
            itemFilePattern = @"NER_MAPS_STATIC_WORD_COUNTRY_MAP_3_*.json";
            results = TokenHelperStatic.MergeTokensInFiles(itemFolder, itemFilePattern, tokens);

            // Prov / State
            tokens.Add("NER_MAPS_STATIC_GRAMMAR_BLOCK_PROV_STATE_MAP_2_", "PROV_STATE_");
            tokens.Add("NER_MAPS_STATIC_WORD_PROV_STATE_MAP_2_", "PROV_STATE_");
            tokens.Add("PROV_STATE_MAP_2_", "PROV_STATE_");

            itemFolder = @"C:\af\2024\Libraries\NerEngine\v8\Data\Initialization\ner\Geography\Prov_States\GrammarBlock";
            itemFilePattern = @"PROV_STATE_MAP_2_*.json";
            results = TokenHelperStatic.MergeTokensInFiles(itemFolder, itemFilePattern, tokens);
            itemFilePattern = @"NER_MAPS_STATIC_GRAMMAR_BLOCK_PROV_STATE_MAP_2_*.json";
            results = TokenHelperStatic.MergeTokensInFiles(itemFolder, itemFilePattern, tokens);

            itemFolder = @"C:\af\2024\Libraries\NerEngine\v8\Data\Initialization\ner\Geography\Prov_States\Word";
            itemFilePattern = @"PROV_STATE_MAP_2_*.json";
            results = TokenHelperStatic.MergeTokensInFiles(itemFolder, itemFilePattern, tokens);
            itemFilePattern = @"NER_MAPS_STATIC_WORD_PROV_STATE_MAP_2_*.json";
            results = TokenHelperStatic.MergeTokensInFiles(itemFolder, itemFilePattern, tokens);
        }

        #endregion

        #region 006 - ValidateAllTemplates

        [TestMethod]
        public void Test_006_001_ValidateAllTemplates_Empty()
        {
            Assert.ThrowsException<ArgumentNullException>(() => TokenHelperStatic.ValidateAllTemplates(string.Empty, string.Empty, string.Empty, string.Empty));
            Assert.ThrowsException<ArgumentNullException>(() => TokenHelperStatic.ValidateAllTemplates(new List<string>(), string.Empty, string.Empty, string.Empty));
        }

        [TestMethod]
        public void Test_006_002_ValidateAllTemplates_ProperTest()
        {
            string templatesToTest = @"C:\_unit_test\Template_Engine\Data\TestTemplates\TemplatesToTest";
            string destinationTemplateFolder = @"C:\_unit_test\Template_Engine\Data\TestTemplates\Results";
            string expectedResultsFolder = @"C:\_unit_test\Template_Engine\Data\TestTemplates\ExpectedResults";
            string tokenWrappers = "[[TOKEN]]";
            var results = TokenHelperStatic.ValidateAllTemplates(tokenWrappers, templatesToTest, destinationTemplateFolder, expectedResultsFolder);

        }

        #endregion
    }
}