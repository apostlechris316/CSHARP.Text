/********************************************************************************
 * Univeral Content Processing Engine
 * 
 * This engine accepts a piece of content from a source and determines its type 
 * and how to process it. This engine uses unsupervised learning to extend itself. 
 * It also provides a console for supervised learning sessions.
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 ********************************************************************************/

namespace TestTextString
{
    using CSHARP.V8.Helpers.TextString;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;

    [TestClass]
    public class TestCsvStringHelper
    {
        [TestMethod]
        public void Test_001_001_ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces_EmptyString()
        {
            CsvStringHelper csvStringHelper = new();

            // passing both as empty
            Assert.ThrowsException<ArgumentNullException>(() => CsvStringHelperStatic.ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(string.Empty, string.Empty));
            Assert.ThrowsException<ArgumentNullException>(() => csvStringHelper.ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(string.Empty, string.Empty));

            // passing nameOfColumnsToProcess as empty
            string sampleTestString = "TEST";
            Assert.ThrowsException<ArgumentNullException>(() => CsvStringHelperStatic.ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(sampleTestString, string.Empty));
            Assert.ThrowsException<ArgumentNullException>(() => csvStringHelper.ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(sampleTestString, string.Empty));
        }

        [TestMethod]
        public void Test_001_002_ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces_SampleStrings()
        {
            CsvStringHelper csvStringHelper = new();

            // Test No Header Row
            string sampleTestString = "TEST";
            Assert.ThrowsException<ArgumentException>(() => CsvStringHelperStatic.ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(sampleTestString, "NonExistantColumn"));
            Assert.ThrowsException<ArgumentException>(() => csvStringHelper.ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(sampleTestString, "NonExistantColumn"));

            // Test column in nameOfColumnsToProcess is not in header
            sampleTestString = "COL_1,COL_2\r\n1,2\r\n";
            Assert.ThrowsException<ArgumentException>(() => CsvStringHelperStatic.ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(sampleTestString, "NonExistantColumn"));
            Assert.ThrowsException<ArgumentException>(() => csvStringHelper.ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(sampleTestString, "NonExistantColumn"));

            // Test with valid column nothing to clean
            sampleTestString = "COL_1,COL_2\r\n1,2\r\n";
            Assert.IsTrue(sampleTestString == CsvStringHelperStatic.ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(sampleTestString, "col_1"));
            Assert.IsTrue(sampleTestString == csvStringHelper.ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(sampleTestString, "col_1"));

            // Test with valid column and some data contains consecutive underscores. Only fixing one column
            sampleTestString = "COL_1,COL_2\r\nTest__ID_001,Test__ID____002\r\n";
            Assert.IsTrue("COL_1,COL_2\r\nTest_ID_001,Test__ID____002\r\n" == CsvStringHelperStatic.ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(sampleTestString, "col_1"));
            Assert.IsTrue("COL_1,COL_2\r\nTest_ID_001,Test__ID____002\r\n" == csvStringHelper.ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(sampleTestString, "col_1"));

            // Test with valid column and some data contains consecutive underscores. Only fixing both column
            sampleTestString = "COL_1,COL_2\r\nTest__ID_001,Test__ID____002\r\n";
            Assert.IsTrue("COL_1,COL_2\r\nTest_ID_001,Test_ID_002\r\n" == CsvStringHelperStatic.ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(sampleTestString, "COL_1,col_2"));
            Assert.IsTrue("COL_1,COL_2\r\nTest_ID_001,Test_ID_002\r\n" == csvStringHelper.ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(sampleTestString, "COL_1,col_2"));

            // Test with valid column and some data contains consecutive underscores. Only fixing first and last column but leaving the middle one
            sampleTestString = "COL_1,COL_2,col_3\r\nTest - ID-001,Test__ID____002,TEST - ID_ - _003\r\n";
            Assert.IsTrue("COL_1,COL_2,col_3\r\nTest_ID_001,Test__ID____002,TEST_ID_003\r\n" == CsvStringHelperStatic.ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(sampleTestString, "col_1,COL_3"));
            Assert.IsTrue("COL_1,COL_2,col_3\r\nTest_ID_001,Test__ID____002,TEST_ID_003\r\n" == csvStringHelper.ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(sampleTestString, "col_1,COL_3"));
        }
    }
}
