/********************************************************************************
 * Univeral Content Processing Engine
 * 
 * This engine accepts a piece of content from a source and determines its type 
 * and how to process it. This engine uses unsupervised learning to extend itself. 
 * It also provides a console for supervised learning sessions.
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 ********************************************************************************/

namespace TestTextString
{
    using CSHARP.V8.Helpers.TextString;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class TestBase64Helper
    {
        [TestMethod]
        public void Test_001_001_TestIsBase64_EmptyString()
        {
            Assert.IsFalse(Base64HelperStatic.IsBase64(string.Empty));

            var base64Helper = new Base64Helper();
            Assert.IsFalse(base64Helper.IsBase64(string.Empty));
        }

        [TestMethod]
        public void Test_001_002_TestIsBase64_SampleStrings()
        {
            string sampleTestString = "TEST";
            Assert.IsFalse(Base64HelperStatic.IsBase64(sampleTestString));

            var base64Helper = new Base64Helper();
            Assert.IsFalse(base64Helper.IsBase64(sampleTestString));
        }

        [TestMethod]
        public void Test_002_001_TestBase64EncodeDecode_SampleStrings()
        {
            string sampleTestString = "TEST";
            var base64Helper = new Base64Helper();
            string encodedWithStatic = Base64HelperStatic.Base64Encode(sampleTestString);
            string decodedWithNon = base64Helper.Base64Decode(encodedWithStatic);
            string encodeWithNon = base64Helper.Base64Encode(decodedWithNon);
            string decodedWithStatic = Base64HelperStatic.Base64Decode(encodeWithNon);

            Assert.IsTrue(encodedWithStatic == encodeWithNon);
            Assert.IsTrue(decodedWithStatic == decodedWithNon);
        }
    }
}
