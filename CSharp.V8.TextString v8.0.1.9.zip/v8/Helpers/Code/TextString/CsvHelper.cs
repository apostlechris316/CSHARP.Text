﻿/********************************************************************************
 * CSHARP Text Library - General utility to manipulate text strings
 * 
 * NOTE: Adapted from Clinch.Text
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 *          
 * CHANGES: 
 * 
 *  - (v5.0) All methods converted to static
 *  - (v5.0) Additional code to check parameters passed to exit method quicker
 *  - (v8.0) Upgraded to NET8.0. Created a non-static to call the static functions 
 *				as some clients like Powershell needs non-static. 
 *  
 *  POSSIBLE FUTURE IMPROVEMENTS
 *  
 *  -
 *  
 ********************************************************************************/

namespace CSHARP.V8.Helpers.TextString
{
    using System;
    using System.Collections;

    /// <summary>
    /// Assists in working with CSV
    /// </summary>
    public class CsvHelper
    {
        /// <summary>
        /// Converts a list of objects to CSV
        /// </summary>
        /// <param name="collection">Collection of objects to generate CSV from</param>
        /// <param name="type">type of object being generated</param>
        /// <returns>csv string</returns>
        /// <remarks>V2.0.0.2 Case Corrected in method name</remarks>
        public string ConvertToCsv(IEnumerable collection, Type type)
        {
            return CsvHelperStatic.ConvertToCsv(collection, type);
        }
    }
}
