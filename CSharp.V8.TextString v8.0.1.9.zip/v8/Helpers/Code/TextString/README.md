# CSHARP.V8.Helpers.TextString

This QuickStart assists in manipulating and validating text strings

## Getting started

Using the Nuget is simple. Most classes have a static and non-static version the non-static one calls the static one so the code is the same.
The non-static exist so Powershell can more easily make use of the methods.  

Base64Helper: This encodes/decodes strings in Base64.
CsvHelper/CsvStringHelper: These assist with manipulating Csv strings. These will change a lot and will probably become one class
StringHelper: Contains various functions to parse strings
StringValidation: Contains various common Regex and use them to validate a string matches a given format.
(NEW IN 8.0.1) TokenHelper: Assists with getting tokens and replacing tokens in a string
UtfStringWriter: This is a fix for StringWriter to allow it to write Utf8

### Prerequisites

This library only relies on the standard .NET 8.0 calls.

## Usage

string originalString = "my string";
string base64String = Base64HelperStatic.Base64Encode("my string");
string decodedString = Base64HelperStatic.Base64Decode(base64String);
Assert.IsTrue(decodedString == origialString);

## Additional documentation

Provide links to more resources: List links such as detailed documentation, tutorial videos, blog posts, or any other relevant documentation to help users get the most out of your package.

## Feedback

If you have any questions or have feedback email me at chris.williams@readwatchcreate.com