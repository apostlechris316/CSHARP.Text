/********************************************************************************
 * CSHARP Text Library - General utility to manipulate text strings
 * 
 * NOTE: Adapted from Clinch.Text
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 *          
 * CHANGES: 
 * 
 *  - (v5.0) All methods converted to static
 *  - (v5.0) Additional code to check parameters passed to exit method quicker
 *  - (v8.0) Upgraded to NET8.0 
 *  
 * FUTURE IMPROVEMENTS:
 *  
 *  -
 *  
 ********************************************************************************/

namespace CSHARP.V8.Helpers.TextString
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Text.RegularExpressions;

    /// <summary>
    /// General function to help manupulate strings
    /// </summary>
    public static class StringHelperStatic
    {
        #region 001 - Parse Regex 

        /// <summary>
        /// Regular Expression used to extract email address
        /// </summary>
        public const string EmailAddressRegex = @"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";

        /// <summary>
        /// Alternative regex for extracting email
        /// </summary>
        public const string EmailAddressRegex2 = @"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?";
        private static readonly Regex SocialProfileRegex = new Regex(@"(http(s)?:\/\/)?([\w]+\.)?(linkedin\.com|facebook\.com|github\.com|stackoverflow\.com|bitbucket\.org|sourceforge\.net|(\w+\.)?codeplex\.com|code\.google\.com).*?(?=\s)", RegexOptions.Compiled | RegexOptions.IgnoreCase);

        /// <summary>
        /// Regular Expression used to extract phone number
        /// </summary>
        public const string PhoneRegex = @"(\(\+[0-9]{1,3}\)[\.\s]?)?[0-9]{7,14}(?:x.+)?";

        /// <summary>
        /// Second alternative to find phone number
        /// </summary>
        public const string PhoneRegex2 = @"(?<Telephone>([0-9]|[ ]|[-]|[\(]|[\)]|ext.|[,])+)([ ]|[:]|\t|[-])*(?<Where>Home|Office|Work|Away|Fax|FAX|Phone)|(?<Where>Home|Office|Work|Away|Fax|FAX|Phone|Daytime|Evening)([ ]|[:]|\t|[-])*(?<Telephone>([0-9]|[ ]|[-]|[\(]|[\)]|ext.|[,])+)|(?<Telephone>([(]([0-9]){3}[)]([ ])?([0-9]){3}([ ]|-)([0-9]){4}))";

        /// <summary>
        /// Third alternative to find phone number
        /// </summary>
        public const string PhoneRegex3 = @"[01]?[- .]?(\([2-9]\d{2}\)|[2-9]\d{2})[- .]?\d{3}[- .]?\d{4}$";

        /// <summary>
        /// Get all strings that match the given expression in the text provided
        /// </summary>
        /// <param name="text">Text containing the pattern</param>
        /// <param name="regexPattern">RexEx Pattern to check for</param>
        /// <returns></returns>
        /// <remarks>v8.0.1.2 - changed return value to string array</remarks.>
        public static string [] GetAllMatches(string text, string regexPattern)
        {
            var matchList = new List<string>();
            var regex = new Regex(regexPattern);
            var matches = regex.Matches(text);
            foreach(Match match in matches)
            {
                matchList.Add(match.ToString());
            }

            return matchList.ToArray();
        }

        /// <summary>
        /// Get all strings that match the given expression in the text provided
        /// </summary>
        /// <param name="text">Text containing the pattern</param>
        /// <param name="regexPatterns">RexEx Pattern to check for</param>
        /// <returns></returns>
        /// <remarks<v8.0.1.2 - converted parameter and return value to string array
        public static string []? GetAllMatchesViaLoop(string text, string[] regexPatterns)
        {
            var textToProcess = text;
            Match? match = null;

            var matchList = new List<string>();
            foreach (var regexPattern in regexPatterns)
            {
                if (match == null || match.Captures.Count == 0)
                {
                    var regex = new Regex(regexPattern);
                    match = regex.Match(text);
                }
            }

            while (match != null && match.Captures.Count > 0)
            {
                matchList.Add(match.ToString());
                textToProcess = textToProcess.Replace(match.ToString(), string.Empty);
                match = null;

                foreach (var regexPattern in regexPatterns)
                {
                    if (match == null || match.Captures.Count == 0)
                    {
                        var regex = new Regex(regexPattern);
                        match = regex.Match(textToProcess);
                    }
                }
            }

            return matchList.ToArray();
        }

        #endregion

        #region 002 - ConvertToAlphaNumeric

        /// <summary>
        /// Removes all non-alpha-numeric from string.
        /// </summary>
        /// <param name="toConvert">String to remove alpha-numeric from</param>
        /// <param name="removeWhiteSpace">if true removes spaces and, tabs.</param>
        /// <returns>alpha-numeric string</returns>
        public static string ConvertToAlphaNumeric(string toConvert, bool removeWhiteSpace)
        {
            return ConvertToAlphaNumeric(toConvert, removeWhiteSpace, true);
        }

        /// <summary>
        /// Converts all non-alpha-numeric to spaces in the string.  
        /// Removes White Spaces and Underscores if requested
        /// </summary>
        /// <param name="toConvert">String to remove alpha-numeric from</param>
        /// <param name="removeWhiteSpace">if true removes spaces and, tabs.</param>
        /// <param name="removeUnderScore">if true reomoves underscores</param>
        /// <returns>alpha-numeric string</returns>
        public static string ConvertToAlphaNumeric(string toConvert, bool removeWhiteSpace, bool removeUnderScore)
        {
            return ConvertToAlphaNumeric(toConvert,removeWhiteSpace, removeUnderScore, false, false);
        }
        /// <summary>
        /// Converts all non-alpha-numeric to spaces in the string.  
        /// </summary>
        /// <param name="toConvert">String to remove alpha-numeric from</param>
        /// <param name="removeWhiteSpace">if true removes spaces and, tabs.</param>
        /// <param name="removeUnderScore">if true removes underscores</param>
        /// <param name="replaceSpaceWithUnderScore">if true and we are not removing space or underscores then replaces all spaces with underscore</param>
        /// <param name="consolidateConsecutiveUnderscores">if true and we are not removing space or underscores then replaces all consecutive underscores with a single underscore</param>
        /// <returns></returns>
        /// <remarks>NEW IN v5.0.0.0</remarks>
        public static string ConvertToAlphaNumeric(string toConvert, bool removeWhiteSpace, bool removeUnderScore, bool replaceSpaceWithUnderScore, bool consolidateConsecutiveUnderscores)
        { 
            var result = string.Empty;

            // if no string passed in then simply return no string
            if (string.IsNullOrEmpty(toConvert)) return result;

            var toIngnore = removeUnderScore ? "!@#$%^&*()-_=+\\/?<>|[{}];:`'\".,���\"" : "!@#$%^&*()-=+\\/?<>|[{}];:`'\".,�����\"";

            var charactersToIgnore = toIngnore.ToCharArray();
            var cleaned = toConvert.Replace("\r", string.Empty).Replace("\n", string.Empty);
            var array = charactersToIgnore;
            cleaned = array.Aggregate(cleaned, (current, ignore) => current.Replace(ignore, ' '));

            if (removeWhiteSpace) cleaned = cleaned.Replace(" ", string.Empty).Replace("\t", string.Empty);

            // if we are not removing the underscores and are replacing space with underscore
            if (removeWhiteSpace == false && removeUnderScore == false && replaceSpaceWithUnderScore)
            {
                cleaned = cleaned.Replace(" ", "_");
                if (consolidateConsecutiveUnderscores && cleaned.Length > 0)
                {
                    // while we are still finding consecutive underscores
                    while (cleaned.IndexOf("__") > 0)
                    {
                        cleaned = cleaned.Replace("__", "_");
                    }
                }
            }

            result = cleaned;

            return result;
        }

        #endregion

        #region 003 - Random String

        /// <summary>
        /// Generates an 8 character random string based on random filename function
        /// </summary>
        /// <returns>8 character random number</returns>
        public static string Get8CharacterRandomString()
        {
            var path = Path.GetRandomFileName();
            path = path.Replace(".", string.Empty); // Remove period.
            return path.Substring(0, 8);  // Return 8 character string
        }

        #endregion

        #region 004 - Convert To Csv

        /// <summary>
        /// Converts a list of objects to string containing CSV including header row
        /// </summary>
        /// <param name="collection">Collection of objects to generate CSV from</param>
        /// <param name="type">type of object being generated</param>
        /// <returns>csv string</returns>
        /// <remarks>V2.0.0.2 Case Corrected in method name</remarks>
        public static string ConvertToCsv(IEnumerable collection, Type type)
        {
            var stringBuilder = new StringBuilder();
            var header = new StringBuilder();

            // Gets all  properies of the class
            var properties = type.GetProperties();

            // Create CSV header using the classes properties
            foreach (var propertyForHeader in properties) header.Append(propertyForHeader.Name + ",");

            stringBuilder.AppendLine(header.ToString());

            foreach (var objectToGenerateCsvRowFor in collection)
            {
                var body = new StringBuilder();

                // Create new item
                var t1 = objectToGenerateCsvRowFor;
                foreach (string? propertyForBody in properties.Select(p => p.GetValue(t1, null)))
                {
                    if (propertyForBody != null)
                    {
                        // Ensure column values with commas in it are quoted
                        if (propertyForBody.ToString().IndexOf(',') > -1) body.Append("\"" + propertyForBody + "\",");
                        else body.Append(propertyForBody + ",");
                    }
                    else body.Append(",");
                }

                stringBuilder.AppendLine(body.ToString());
            }
            return stringBuilder.ToString();
        }

        #endregion

        #region 005 - UrlFriendly 

        /// <summary>
        /// Converts an url friendly string by replacing all non-alphanumeric and spaces with an alternate string
        /// </summary>
        /// <param name="toConvert">String to convert</param>
        /// <param name="replaceUnfriendlyWith">string to replace non-friendly characters with</param>
        /// <returns></returns>
        /// <remarks>NEW in V2.0.0.8
        /// 2.0.0.10 - Spaces were being replaced with empty string rather than replaceUnfriendlyWith
        /// </remarks>
        public static string ConvertToUrlFriendly(string toConvert, string replaceUnfriendlyWith)
        {
            var result = string.Empty;
            if (string.IsNullOrEmpty(toConvert)) return result;

            // Repalce all non-alphanumeric with space
            const string toIngnore = "!@#$%^&*()-=+\\/?<>|[{}];:`'\".,�����\"";
            var charactersToIgnore = toIngnore.ToCharArray();
            var cleaned = toConvert.Replace("\r", string.Empty).Replace("\n", string.Empty);
            var array = charactersToIgnore;
            cleaned = array.Aggregate(cleaned, (current, ignore) => current.Replace(ignore, ' '));

            // Change all whitespace with string
            cleaned = cleaned.Replace(" ", replaceUnfriendlyWith).Replace("\t", replaceUnfriendlyWith);

            result = cleaned;

            return result;
        }

        #endregion

        #region 006 - Dictionary To ... 

        /// <summary>
        /// Takes the pairs from the string,string dictionary and converts them to a delimited string
        /// </summary>
        /// <param name="stringDictionary">Dictionary with a string key and string value</param>
        /// <param name="pairToken">token to put between each pair</param>
        /// <param name="partToken">token to put between the key and value</param>
        /// <returns>Delimited string however if the value contains the partToken or pairToken it will be Base64 Encoded</returns>
        /// <remarks>NEW IN v5.0.0.0. Allowed passsing character tokens instead of strings </remarks>
        public static string DictionaryToDelimitedString(Dictionary<string, string> stringDictionary, char pairToken, char partToken)
        {
            return DictionaryToDelimitedString(stringDictionary, pairToken.ToString(), partToken.ToString());
        }

        /// <summary>
        /// Takes the pairs from the string,string dictionary and converts them to a delimited string
        /// </summary>
        /// <param name="stringDictionary">Dictionary with a string key and string value</param>
        /// <param name="pairToken">token to put between each pair</param>
        /// <param name="partToken">token to put between the key and value</param>
        /// <returns>Delimited string however if the value contains the partToken or pairToken it will be Base64 Encoded</returns>
        public static string DictionaryToDelimitedString(Dictionary<string, string> stringDictionary, string pairToken, string partToken)
        {
            StringBuilder csvString = new StringBuilder();
            foreach (var item in stringDictionary)
            {
                // each pair is separated by a pipe
                if (stringDictionary.Count() > 0)
                {
                    csvString.Append(pairToken);
                }

                if (item.Value.Contains(partToken) || item.Value.Contains(pairToken))
                {
                    // if it contains a we base64 it
                    csvString.Append(item.Key + partToken + "BASE64:" + Base64HelperStatic.Base64Encode(item.Value));
                }
                else
                {
                    csvString.Append(item.Key + partToken + item.Value);
                }
            }

            return csvString.ToString();
        }

        #endregion

        #region 007 - String Splitters

        /// <summary>
        /// Splits a string into its words for manipulation
        /// </summary>
        /// <param name="toSplit">String to split into words</param>
        /// <returns></returns>
        /// <remarks>v8.0.1.2 - return value is now string array
        /// Uses default values to split words</remarks>
            public static string[] SplitStringIntoWords(string toSplit)
        {
            return SplitStringIntoWords(toSplit, new char[] { ' ', ',', ';', ':', '(', ')', '{', '}', '[', ']', '!', '.', '?' });
        }

        /// <summary>
        /// Splits a string into its words for manipulation
        /// </summary>
        /// <param name="toSplit">String to split into words</param>
        /// <param name="endOfWordToken"></param>
        /// <returns></returns>
        /// <remarks>v8.0.1.2 - changed return value to string array
        /// v2.0.0.11 Strips string before splitting into words</remarks>
        public static string [] SplitStringIntoWords(string toSplit, char[] endOfWordToken)
        {
            var words = new List<string>();
            var splitBuffer = toSplit.Trim();

            while (string.IsNullOrEmpty(splitBuffer) == false)
            {
                string foundWord = GetBeforeOneOf(splitBuffer, endOfWordToken, "EXCLUDING");

                // only add word if not empty string.
                if (string.IsNullOrEmpty(foundWord) == false) words.Add(foundWord);

                splitBuffer = (foundWord == splitBuffer)
                    ? string.Empty
                    : GetAfterOneOf(splitBuffer, endOfWordToken, "EXCLUDING").Trim();
            }

            return words.ToArray();
        }

        /// <summary>
        /// Splits a string into sentences for manipulation
        /// </summary>
        /// <param name="toSplit"></param>
        /// <returns></returns>
        /// <remarks>v8.0.1.1 return type changed from list to string array</remarks>
        public static string[] SplitStringIntoSentences(string toSplit)
        {
            return Regex.Split(toSplit, @"(?<=[\.!\?])\s+");
        }

        /// <summary>
        /// Gets the first line in the string
        /// </summary>
        /// <param name="toSplit">string containing lines</param>
        /// <returns></returns>
        public static string GetFirstLine(string toSplit)
        {
            const RegexOptions options = ((RegexOptions.IgnorePatternWhitespace | RegexOptions.Multiline)
                                            | RegexOptions.IgnoreCase);
            var reg = new Regex("(?:^|,)(\\\"(?:[^\\\"]+|\\\"\\\")*\\\"|[^,]*)", options);
            var coll = reg.Matches(toSplit);
            return coll[0].Value.Trim('"').Trim(',').Trim('"').Trim();
        }

        /// <summary>
        /// Splits a string into lines for manipulation
        /// </summary>
        /// <param name="toSplit">string containing lines</param>
        /// <returns></returns>
        /// <remarks>return value changed to string array</remarks>
        public static string[] SplitStringIntoLines(string toSplit)
        {
            const RegexOptions options = ((RegexOptions.IgnorePatternWhitespace | RegexOptions.Multiline)
                                            | RegexOptions.IgnoreCase);
            var reg = new Regex("(?:^|,)(\\\"(?:[^\\\"]+|\\\"\\\")*\\\"|[^,]*)", options);
            var coll = reg.Matches(toSplit);
            var items = new string[coll.Count];
            var i = 0;
            foreach (Match m in coll) items[i++] = m.Groups[0].Value.Trim('"').Trim(',').Trim('"').Trim();
            return items;
        }

        /// <summary>
        /// Splits the string to dictionary given tokens.
        /// </summary>
        /// <param name="toSplit">string to split</param>
        /// <param name="keyValueToken">token to split key and value</param>
        /// <param name="entryToken">token to split each dictionary entry</param>
        /// <returns></returns>
        /// <remarks>NEW in v2.0.0.3</remarks>
        public static Dictionary<string, string> SplitStringToDictionary(string toSplit, char keyValueToken, char entryToken)
        {
            var stringList = toSplit.Split(entryToken);

            return stringList.Select(pair => pair.Split(keyValueToken)).ToDictionary(keyValue => keyValue[0], keyValue => keyValue.Length > 1 ? keyValue[1] : string.Empty);
        }

        /// <summary>
        /// Splits the string to dictionary given keyvalue token. This assumes one pair per line
        /// </summary>
        /// <param name="toSplit">string to split</param>
        /// <param name="keyValueToken">token to split key and value</param>
        /// <returns></returns>
        /// <remarks>NEW in v5.0.0.0</remarks>
        public static Dictionary<string, string> SplitStringToDictionary(string toSplit, char keyValueToken)
        {
            var stringList = toSplit.Split("\r\n");

            return stringList.Select(pair => pair.Split(keyValueToken)).ToDictionary(keyValue => keyValue[0], keyValue => keyValue.Length > 1 ? keyValue[1] : string.Empty);
        }

        /// <summary>
        /// Splits the string to dictionary given tokens, only including duplicate keys once.
        /// </summary>
        /// <param name="toSplit">string to split</param>
        /// <param name="keyValueToken">token to split key and value</param>
        /// <param name="entryToken">token to split each dictionary entry</param>
        /// <returns></returns>
        /// <remarks>NEW in v2.0.0.5</remarks>
        public static Dictionary<string, string> SplitStringToDistinctDictionary(string toSplit, char keyValueToken, char entryToken)
        {
            var stringList = toSplit.Split(entryToken);
            var distinctDictionary = new Dictionary<string, string>();

            foreach (var itemPairs in stringList.Select(item => item.Split(keyValueToken)).Where(itemPairs => distinctDictionary.ContainsKey(itemPairs[0]) == false))
            {
                distinctDictionary.Add(itemPairs[0], itemPairs[1]);
            }

            return distinctDictionary;
        }


        /// <summary>
        /// Splits the string to dictionary on the end of line marker.
        /// </summary>
        /// <param name="input">string to split</param>
        /// <param name="token">token to split key and value</param>
        /// <returns></returns>
        /// <remarks>FIX: 2.0.0.2 - Exception on Line with key and no value</remarks>
        public static Dictionary<string, string> SplitStringToDictionaryOnEndOfLine(string input, char token)
        {
            var stringList = input.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            return stringList.Select(pair => pair.Split(token)).ToDictionary(keyValue => keyValue[0], keyValue => keyValue.Length > 1 ? keyValue[1] : string.Empty);
        }

        /// <summary>
        /// Splits the string on the end of line marker.
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static string[] SplitStringOnEndOfLine(string input)
        {
            return input.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
        }

        /// <summary>
        /// Splits the string on the end of line marker. Only include distinct strings
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        /// <remarks>v8.0.1.2 return value changed to t
        /// NEW in 2.0.0.6</remarks>
        public static string[] SplitStringOnEndOfLineDistinct(string input)
        {
            var stringList = new List<string>();
            foreach (var item in input.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None).Where(item => stringList.Contains(item) == false))
            {
                stringList.Add(item);
            }

            return stringList.ToArray();
        }

        #endregion

        #region 008 - StringArray To ...

        /// <summary>
        /// Builds a delimited string from a string array. Only include distinct strings
        /// </summary>
        /// <param name="items">array of strings</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        /// <remarks>NEW in 2.0.0.6</remarks>
        public static string StringArrayToDistinctDelimitedString(string[] items, char token)
        {
            var returnValue = new StringBuilder();
            var itemList = new List<string>();
            var firstItem = true;
            foreach (var item in items)
            {
                if (itemList.Contains(item) == false)
                {
                    if (!firstItem) returnValue.Append(token);
                    itemList.Add(item);
                    returnValue.Append(item);
                }
                firstItem = false;
            }
            return returnValue.ToString();
        }

        /// <summary>
        /// Builds a delimited string from a string array
        /// </summary>
        /// <param name="items">array of strings</param>
        /// <param name="token">delimiter</param>
        /// <remarks>NEW IN 8.0.0.4 this version supports string token as well</remarks>
        /// <returns></returns>
        public static string StringArrayToDelimitedString(string[] items, string token)
        {
            var returnValue = new StringBuilder();
            var firstItem = true;
            foreach (var item in items)
            {
                if (!firstItem) returnValue.Append(token);
                returnValue.Append(item);
                firstItem = false;
            }
            return returnValue.ToString();
        }

        /// <summary>
        /// Builds a delimited string from a string array
        /// </summary>
        /// <param name="items">array of strings</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        public static string StringArrayToDelimitedString(string[] items, char token)
        {
            var returnValue = new StringBuilder();
            var firstItem = true;
            foreach (var item in items)
            {
                if (!firstItem) returnValue.Append(token);
                returnValue.Append(item);
                firstItem = false;
            }
            return returnValue.ToString();
        }

        #endregion

        #region 009 - StringList To ...

        /// <summary>
        /// Builds a delimited string from a list of strings
        /// </summary>
        /// <param name="items">list of strings</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        /// <remarks> v8.0.1.1 items parameter changed to string array
        /// NEW IN v5.0.0.0. This version allows you to pass a string for a token to support multi-character tokens eg. || </remarks>
        public static string StringListToDelimitedString(List<string> items, char token)
        {
            var returnValue = new StringBuilder();
            var firstItem = true;
            foreach (var item in items)
            {
                if (!firstItem) returnValue.Append(token);
                returnValue.Append(item);
                firstItem = false;
            }
            return returnValue.ToString();
        }

        /// <summary>
        /// Builds a delimited string from a list of strings
        /// </summary>
        /// <param name="items">list of strings</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        /// <remarks> v8.0.1.1 items parameter changed to string array
        /// NEW IN v5.0.0.0. This version allows you to pass a string for a token to support multi-character tokens eg. || </remarks>
        public static string StringListToDelimitedString(List<string> items, string token)
        {
            var returnValue = new StringBuilder();
            var firstItem = true;
            foreach (var item in items)
            {
                if (!firstItem) returnValue.Append(token);
                returnValue.Append(item);
                firstItem = false;
            }
            return returnValue.ToString();
        }

        /// <summary>
        /// Builds a string containing a string per line from a delimited string 
        /// </summary>
        /// <param name="items">list of strings</param>
        /// <returns></returns>
        /// <remarks>v8.0.1.1 items parameter changed to string array
        /// NEW in 2.0.0.7</remarks>
        public static string StringArrayToEndOfLineDelimited(string[] items)
        {
            var returnValue = new StringBuilder();
            var firstItem = true;
            foreach (var item in items)
            {
                if (!firstItem) returnValue.Append("\r\n");
                returnValue.Append(item);
                firstItem = false;
            }

            return returnValue.ToString();
        }

        /// <summary>
        /// Builds a string containing a string per line from a delimited string 
        /// </summary>
        /// <param name="items">list of strings</param>
        /// <returns></returns>
        /// <remarks>v8.0.1.1 items parameter changed to string array
        /// NEW in 2.0.0.7</remarks>
        public static string StringListToEndOfLineDelimited(List<string> items)
        {
            var returnValue = new StringBuilder();
            var firstItem = true;
            foreach (var item in items)
            {
                if (!firstItem) returnValue.Append("\r\n");
                returnValue.Append(item);
                firstItem = false;
            }

            return returnValue.ToString();
        }

        #endregion

        #region 010 - Delimited String To ...

        /// <summary>
        /// Builds an array of strings from a delimited string 
        /// </summary>
        /// <param name="delimitedString">delimited string</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        /// <remarks>FIXED v2.0.0.10 - Returns null if null passed in</remarks>
        public static List<Guid>? DelimitedStringToGuidList(string delimitedString, char token)
        {
            return string.IsNullOrEmpty(delimitedString) ? null : delimitedString.Split(token).Select(item => new Guid(item)).ToList();
        }

        /// <summary>
        /// Builds an array of strings from a delimited string 
        /// </summary>
        /// <param name="delimitedString">delimited string</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        /// <remarks>FIXED v2.0.0.10 - Returns null if null passed in</remarks>
        public static string[]? DelimitedStringToStringArray(string delimitedString, char token)
        {
            return (string.IsNullOrEmpty(delimitedString)) ? null : delimitedString.Split(token);
        }

        /// <summary>
        /// Builds a list of strings from a delimited string 
        /// </summary>
        /// <param name="delimitedString">delimited string</param>
        /// <param name="token">character delimiter</param>
        /// <returns></returns>
        /// <remarks>FIXED v2.0.0.10 - Returns null if null passed in</remarks>
        public static List<string>? DelimitedStringToStringList(string delimitedString, char token)
        {
            return (string.IsNullOrEmpty(delimitedString)) ? null : delimitedString.Split(token).ToList();
        }

        /// <summary>
        /// Builds a list of strings from a delimited string 
        /// </summary>
        /// <param name="delimitedString">delimited string</param>
        /// <param name="token">string delimiter</param>
        /// <returns></returns>
        /// <remarks>NEW IN v5.0.0.0 - Returns null if null passed in</remarks>
        public static List<string>? DelimitedStringToStringList(string delimitedString, string token)
        {
            return (string.IsNullOrEmpty(delimitedString)) ? null : delimitedString.Split(token).ToList();
        }

        /// <summary>
        /// Builds an array of strings from a delimited string 
        /// </summary>
        /// <param name="delimitedString">delimited string</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        /// <remarks>FIXED v2.0.0.10 - Returns null if null passed in</remarks>
        public static string[]? DelimitedStringToStringArray(string delimitedString, string token)
        {
            return (string.IsNullOrEmpty(delimitedString)) ? null : Regex.Split(delimitedString, token);
        }

        /// <summary>
        /// Builds a string containing a string per line from a delimited string 
        /// </summary>
        /// <param name="delimitedString">delimited string</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        /// <remarks>FIXED v2.0.0.10 - Returns null if null passed in</remarks>
        public static string? DelimitedStringToEndOfLineDelimited(string delimitedString, string token)
        {
            return (string.IsNullOrEmpty(delimitedString)) ? null : delimitedString.Replace(token, "\r\n");
        }

        #endregion

        #region 011 - GuidList To ...

        /// <summary>
        /// Builds a delimited string from a list of strings
        /// </summary>
        /// <param name="items">list of strings</param>
        /// <param name="token">delimiter</param>
        /// <returns></returns>
        public static string GuidListToDelimitedString(List<Guid> items, char token)
        {
            var returnValue = new StringBuilder();
            var firstItem = true;
            foreach (var item in items)
            {
                if (!firstItem) returnValue.Append(token);
                returnValue.Append(item);
                firstItem = false;
            }
            return returnValue.ToString();
        }

        #endregion

        #region 012 - GetAfter 

        /// <summary>
        /// Removes all text after the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <returns></returns>
        public static string GetAfter(string snippet, string token)
        {
            return GetAfter(snippet, token, "INCLUDING");
        }
        /// <summary>
        /// Removes all text after the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public static string GetAfter(string snippet, string token, bool including)
        {
            return GetAfter(snippet, token, (including ? "INCLUDING" : "EXCLUDING"));
        }
        /// <summary>
        /// Removes all text after the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public static string GetAfter(string snippet, string token, string including)
        {
            string returnValue;
            var index = snippet.IndexOf(token, StringComparison.Ordinal);
            if (index > -1)
            {
                returnValue = snippet.Substring(index + token.Length);
                if (including == "INCLUDING") returnValue = token + returnValue;
            }
            else
            {
                returnValue = snippet;
            }
            return returnValue;
        }

        /// <summary>
        /// Removes all text after the first occurence of one of the given tokens
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="tokens">array of tokens to look for</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        /// <remarks>NEW In v2.0.0.9</remarks>
        public static string GetAfterOneOf(string snippet, char[] tokens, string including)
        {
            string returnValue;
            var index = snippet.Length;
            var token = string.Empty;

            foreach (var foundToken in tokens)
            {
                var foundIndex = snippet.IndexOf(foundToken.ToString(), StringComparison.Ordinal);
                if (foundIndex >= index || foundIndex == -1) continue;

                index = foundIndex;
                token = foundToken.ToString();
            }

            if (index > -1)
            {
                returnValue = snippet.Substring(index + token.Length);
                if (including == "INCLUDING") returnValue = token + returnValue;
            }
            else
            {
                returnValue = snippet;
            }

            return returnValue;
        }

        #endregion

        #region 013 - GetAfterLast 

        /// <summary>
        /// Removes all text after the last occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public static string GetAfterLast(string snippet, string token, bool including)
        {
            return GetAfterLast(snippet, token, (including ? "INCLUDING" : "EXCLUDING"));
        }

        /// <summary>
        /// Removes all text after the last occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public static string GetAfterLast(string snippet, string token, string including)
        {
            string returnValue;
            var index = snippet.LastIndexOf(token, StringComparison.Ordinal);
            if (index > -1)
            {
                returnValue = snippet.Substring(index + token.Length);
                if (including == "INCLUDING") returnValue = token + returnValue;
            }
            else
            {
                returnValue = snippet;
            }
            return returnValue;
        }

        #endregion

        #region 014 - GetAfterPosition

        /// <summary>
        /// Gets text after a given position
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="position">position to get content after</param>
        /// <returns></returns>
        public static string GetAfterPosition(string snippet, int position)
        {
            return position > -1 ? snippet.Substring(position) : snippet;
        }

        #endregion

        #region 015 - DeleteAfter

        /// <summary>
        /// Removes all text after the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <returns></returns>
        public static string DeleteAfter(string snippet, string token)
        {
            return DeleteAfter(snippet, token, "INCLUDING");
        }

        /// <summary>
        /// Removes all text after the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public static string DeleteAfter(string snippet, string token, bool including)
        {
            return DeleteAfter(snippet, token, (including ? "INCLUDING" : "EXCLUDING"));
        }
        /// <summary>
        /// Removes all text after the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public static string DeleteAfter(string snippet, string token, string including)
        {
            string returnValue;
            var index = snippet.IndexOf(token, StringComparison.Ordinal);
            if (index > -1)
            {
                returnValue = snippet.Substring(0, index);
                if (including == "INCLUDING") returnValue = returnValue + token;
            }
            else
            {
                returnValue = snippet;
            }
            return returnValue;
        }

        #endregion

        #region 016 - DeleteAfterLast 

        /// <summary>
        /// Removes all text after the last occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public static string DeleteAfterLast(string snippet, string token, bool including)
        {
            return DeleteAfterLast(snippet, token, (including ? "INCLUDING" : "EXCLUDING"));
        }

        /// <summary>
        /// Removes all text after the last occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public static string DeleteAfterLast(string snippet, string token, string including)
        {
            string returnValue;
            var index = snippet.LastIndexOf(token, StringComparison.Ordinal);
            if (index > -1)
            {
                returnValue = snippet.Substring(0, index);
                if (including == "INCLUDING") returnValue = returnValue + token;
            }
            else
            {
                returnValue = snippet;
            }
            return returnValue;
        }

        #endregion

        #region 017 - FindOneOf

        /// <summary>
        /// Finds the first occurance of one of the characters in the tokens string in the snippet
        /// </summary>
        /// <param name="snippet">String to search inside</param>
        /// <param name="tokens">character tokens to search for inside snippet</param>
        /// <returns></returns>
        public static int FindOneOf(string snippet, char[] tokens)
        {
            var index = -1;

            foreach (var foundIndex in tokens.Select(foundToken => snippet.IndexOf(foundToken.ToString(), StringComparison.Ordinal)).Where(foundIndex => foundIndex < index))
            {
                index = foundIndex;
            }

            return index;
        }

        #endregion

        #region 018 - GetFirst

        /// <summary>
        /// Gets the first x characters in a string
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="length">number of characters to get from the beginning for the string</param>
        /// <returns></returns>
        public static string GetFirst(string snippet, int length)
        {
            return GetFirst(snippet, length, false);
        }

        /// <summary>
        /// Gets the first x characters in a string
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="length">number of characters to get from the beginning for the string</param>
        /// <param name="addEllipsis">if true, will reduce length by an addition 3 characters and adds ... to the end</param>
        /// <returns></returns>
        public static string GetFirst(string snippet, int length, bool addEllipsis)
        {
            return length < snippet.Length ? (addEllipsis ? snippet.Substring(0, length - 3) + "..." : snippet.Substring(0, length)) : snippet;
        }

        #endregion

        #region 019 - GetLast

        /// <summary>
        /// Gets the last x characters in a string
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="length">number of characters to get from the end for the string</param>
        /// <returns></returns>
        public static string GetLast(string snippet, int length)
        {
            return snippet.Substring(0, snippet.Length - length);
        }

        #endregion

        #region 020 - GetBefore 

        /// <summary>
        /// Removes all text before the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <returns></returns>
        public static string GetBefore(string snippet, string token)
        {
            return GetBefore(snippet, token, "INCLUDING");
        }

        /// <summary>
        /// Removes all text before the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public static string GetBefore(string snippet, string token, bool including)
        {
            return GetBefore(snippet, token, (including ? "INCLUDING" : "EXCLUDING"));
        }

        /// <summary>
        /// Removes all text before the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public static string GetBefore(string snippet, string token, string including)
        {
            string returnValue;
            int index = snippet.IndexOf(token, StringComparison.Ordinal);
            if (index > -1)
            {
                returnValue = snippet.Substring(0, index);
                if (including == "INCLUDING") returnValue = returnValue + token;
            }
            else
            {
                returnValue = snippet;
            }
            return returnValue;
        }

        /// <summary>
        /// Removes all text before the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="tokens">array of tokens to look for</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        /// <remarks>NEW in v2.0.0.9</remarks>
        public static string GetBeforeOneOf(string snippet, char[] tokens, string including)
        {
            string returnValue;
            var index = snippet.Length;
            var token = string.Empty;

            foreach (var foundToken in tokens)
            {
                var foundIndex = snippet.IndexOf(foundToken.ToString(), StringComparison.Ordinal);
                if (foundIndex >= index || foundIndex == -1) continue;

                index = foundIndex;
                token = foundToken.ToString();
            }

            if (index > -1)
            {
                returnValue = snippet.Substring(0, index);
                if (including == "INCLUDING") returnValue = returnValue + token;
            }
            else
            {
                returnValue = snippet;
            }
            return returnValue;
        }

        #endregion

        #region 021 - GetBeforeLast 

        /// <summary>
        /// Removes all text after the last occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <returns></returns>
        public static string GetBeforeLast(string snippet, string token)
        {
            return GetBeforeLast(snippet, token, "INCLUDING");
        }

        /// <summary>
        /// Removes all text after the last occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public static string GetBeforeLast(string snippet, string token, bool including)
        {
            return GetBeforeLast(snippet, token, (including ? "INCLUDING" : "EXCLUDING"));
        }

        /// <summary>
        /// Removes all text after the last occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public static string GetBeforeLast(string snippet, string token, string including)
        {
            string returnValue;
            int index = snippet.LastIndexOf(token, StringComparison.Ordinal);
            if (index > -1)
            {
                returnValue = snippet.Substring(0, index);
                if (including == "INCLUDING") returnValue = returnValue + token;
            }
            else
            {
                returnValue = snippet;
            }
            return returnValue;
        }

        #endregion
        
        #region 022 - GetBeforePosition 

        /// <summary>
        /// Removes all text after a given position in a string
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="position">position to get content before</param>
        /// <returns></returns>
        public static string GetBeforePosition(string snippet, int position)
        {
            string returnValue = position > -1 ? snippet.Substring(0, position) : snippet;
            return returnValue;
        }

        #endregion

        #region 023 - DeleteBefoe

        /// <summary>
        /// Removes all text before the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <returns></returns>
        public static string DeleteBefore(string snippet, string token)
        {
            return DeleteBefore(snippet, token, "INCLUDING");
        }

        /// <summary>
        /// Removes all text before the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public static string DeleteBefore(string snippet, string token, bool including)
        {
            return DeleteBefore(snippet, token, (including ? "INCLUDING" : "EXCLUDING"));
        }

        /// <summary>
        /// Removes all text before the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content before</param>
        /// <param name="including">Determines if returned string includes the token</param>
        /// <returns></returns>
        public static string DeleteBefore(string snippet, string token, string including)
        {
            string returnValue;
            var index = snippet.IndexOf(token, StringComparison.Ordinal);
            if (index > -1)
            {
                returnValue = snippet.Substring(index + token.Length);
                if (including == "INCLUDING") returnValue = token + returnValue;
            }
            else
            {
                returnValue = snippet;
            }
            return returnValue;
        }

        #endregion

        #region 024 - DeleteBeforePosition 

        /// <summary>
        /// Removes all text before the first occurence of a given token
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="position">position to delete content before</param>
        /// <returns></returns>
        public static string DeleteBeforePosition(string snippet, int position)
        {
            return position > -1 ? snippet.Substring(position) : snippet;
        }

        #endregion

        #region 025 - GetBetween 

        /// <summary>
        /// Gets the string content between the beforeToken and afterToken.
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="afterToken"></param>
        /// <param name="beforeToken"></param>
        /// <param name="including"></param>
        /// <returns></returns>
        public static string GetBetween(string snippet, string afterToken, string beforeToken, bool including)
        {
            return GetBetween(snippet, afterToken, beforeToken, (including ? "INCLUDING" : "EXCLUDING"));
        }

        /// <summary>
        /// Gets the string content between the beforeToken and afterToken.
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="afterToken"></param>
        /// <param name="beforeToken"></param>
        /// <param name="including"></param>
        /// <returns></returns>
        /// <remarks>FIXED v2.0.0.4 - Including was missing before token</remarks>
        public static string GetBetween(string snippet, string afterToken, string beforeToken, string including)
        {
            string returnValue;
            var afterIndex = snippet.IndexOf(afterToken, StringComparison.Ordinal);
            var beforeIndex = snippet.IndexOf(beforeToken, StringComparison.Ordinal);
            if (afterIndex > -1)
            {
                beforeIndex = snippet.Substring(afterIndex + afterToken.Length).IndexOf(beforeToken, StringComparison.Ordinal);
                if (beforeIndex > -1) beforeIndex = afterIndex + beforeIndex + afterToken.Length;
            }
            if (afterIndex < 1 && beforeIndex < 1)
            {
                returnValue = snippet;
            }
            else
            {
                if (afterIndex < 1)
                {
                    returnValue = GetBefore(including == "EXCLUDING" ? snippet.Substring(afterToken.Length) : snippet, beforeToken, including);
                }
                else
                {
                    if (beforeIndex < 1)
                    {
                        returnValue = GetAfter(snippet, afterToken, including);
                    }
                    else
                    {
                        // FIXED v2.0.0.4 - Including was missing before token
                        returnValue = including == "EXCLUDING" ? snippet.Substring(afterIndex + afterToken.Length, beforeIndex - afterIndex - afterToken.Length) : snippet.Substring(afterIndex, beforeIndex - afterIndex + beforeToken.Length);
                    }
                }
            }
            return returnValue;
        }

        #endregion

        #region 026 - GetBetweenPositions

        /// <summary>
        /// Gets the string content between two positions.
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="afterPosition"></param>
        /// <param name="beforePosition"></param>
        /// <param name="beforeTokenLength"></param>
        /// <returns></returns>
        /// <remarks>FIXED v2.0.0.4 - Including was missing before token</remarks>
        public static string GetBetweenPositions(string snippet, int afterPosition, int beforePosition, int beforeTokenLength)
        {
            string returnValue;
            if (afterPosition < 1 && beforePosition < 1)
            {
                returnValue = snippet;
            }
            else
            {
                if (afterPosition < 1)
                {
                    returnValue = GetBeforePosition(snippet, beforePosition);
                }
                else
                {
                    // FIXED v2.0.0.4 - Including was missing before token
                    returnValue = beforePosition < 1 ? GetAfterPosition(snippet, afterPosition) : snippet.Substring(afterPosition, beforePosition - afterPosition + beforeTokenLength);
                }
            }
            return returnValue;
        }

        #endregion

        #region 027 - ReplaceLast

        /// <summary>
        /// Replaces the last occurence of a given token with the replacement string
        /// </summary>
        /// <param name="snippet">String containing text to parse</param>
        /// <param name="token">string to delete content after</param>
        /// <param name="replaceWith"></param>
        /// <returns></returns>
        public static string ReplaceLast(string snippet, string token, string replaceWith)
        {
            string returnValue;
            var index = snippet.LastIndexOf(token, StringComparison.Ordinal);
            if (index > -1)
            {
                returnValue = snippet.Substring(0, index) + replaceWith + snippet.Substring(index + token.Length);
            }
            else
            {
                returnValue = snippet;
            }
            return returnValue;
        }

        #endregion

        #region 028 - GetEverythingBetweenBraces

        /// <summary>
        /// This function will look for the matching end brace. It handles nested braces as long as they ALL match.
        /// </summary>
        /// <param name="snippetStartingWithOpenBrace">The starting brace MUST be the first character</param>
        /// <param name="including">if true the return value will include open and closing brace in the result</param>
        /// <param name="snippetAfterCloseBrace">out parameter that will get everything after the matching closing brace.</param>
        /// <returns>If matching brace found returns everything between the matching braces (including the braces if specified)
        /// </returns>
        /// <exception cref="ArgumentException">This is thrown if snippetStartingWithOpenBrace does not start with the brace</exception>
        /// <exception cref="Exception">This is thrown if we cant find the matching end brace.</exception>
        public static string GetEverythingBetweenBraces(string snippetStartingWithOpenBrace, bool including, out string snippetAfterCloseBrace)
        {
            // if string is empty then we simply return empty string and the out param is simply the in snippet
            if (string.IsNullOrEmpty(snippetStartingWithOpenBrace))
            {
                snippetAfterCloseBrace = snippetStartingWithOpenBrace;
                return String.Empty;
            }

            string remainingToProcess = snippetStartingWithOpenBrace;
            int firstStartBrace = remainingToProcess.IndexOf('{');
            int nextStartBrace = remainingToProcess.IndexOf('{', firstStartBrace + 1);

            // if there are no braces then we simply return empty string and the out param is simply the in snippet
            if (firstStartBrace == -1)
            {
                snippetAfterCloseBrace = snippetStartingWithOpenBrace;
                return String.Empty;
            }

            if (firstStartBrace > 0)
            {
                throw new ArgumentException(nameof(snippetStartingWithOpenBrace) + " should start with the open brace");
            }

            // if there are no nested braces we can simply look for the end and return
            if (nextStartBrace == -1)
            {
                snippetAfterCloseBrace = GetAfter(snippetStartingWithOpenBrace, "}", false);
                return GetBetween(snippetStartingWithOpenBrace, "{", "}", including);
            }

            int nestingLevel = 2;
            int nextEndBrace = snippetStartingWithOpenBrace.IndexOf('}');
            if (nextEndBrace == -1)
            {
                throw new Exception("ERROR: Mismatched end braces");
            }

            // This takes us to the start of the second nested
            string classBlock = GetBeforePosition(snippetStartingWithOpenBrace, nextStartBrace + 1);
            remainingToProcess = GetAfterPosition(snippetStartingWithOpenBrace, nextStartBrace + 1);

            // if we are still looking for end braces and there is still string to search in
            while (nextEndBrace > -1 && nestingLevel > 0 && string.IsNullOrEmpty(remainingToProcess) == false)
            {
                // find the next braces
                nextStartBrace = remainingToProcess.IndexOf('{');
                nextEndBrace = remainingToProcess.IndexOf('}');

                // if we cant find another start brace then the end brace is the matching one
                if (nextStartBrace == -1 && nextEndBrace == -1)
                {
                    throw new Exception("ERROR: Mismatched end braces");
                }

                // the end brace we found is the right one
                else if (nextStartBrace == -1 && nextEndBrace > -1)
                {
                    nestingLevel = nestingLevel - 1;
                    classBlock = classBlock + GetBeforePosition(remainingToProcess, nextEndBrace + 1);
                    remainingToProcess = GetAfterPosition(remainingToProcess, nextEndBrace + 1);
                }
                else if (nextStartBrace > -1 && nextEndBrace == -1)
                {
                    throw new Exception("ERROR: Mismatched end braces");
                }
                else if (nextStartBrace > -1 && nextEndBrace > -1)
                {
                    if (nextStartBrace > nextEndBrace)
                    {
                        nestingLevel = nestingLevel - 1;
                        classBlock = classBlock + GetBeforePosition(remainingToProcess, nextEndBrace + 1);
                        remainingToProcess = GetAfterPosition(remainingToProcess, nextEndBrace + 1);
                    }
                    else
                    {
                        nestingLevel = nestingLevel + 1;
                        classBlock = classBlock + GetBeforePosition(remainingToProcess, nextStartBrace + 1);
                        remainingToProcess = GetAfterPosition(remainingToProcess, nextStartBrace + 1);
                    }
                }
            }

            // if we still need to find end braces but there are not any then throw an exception
            if (nestingLevel > 0 && string.IsNullOrEmpty(remainingToProcess.Replace("\r\n", string.Empty)))
            {
                throw new Exception("ERROR: Mismatched end braces");
            }

            snippetAfterCloseBrace = remainingToProcess;
            return classBlock;
        }

        #endregion

        #region 029 Dictionary Validation

        /// <summary>
        /// If the first and second dictionary are identical
        /// </summary>
        /// <param name="first">dictionary of strings to compare</param>
        /// <param name="second">dictionary of string to comare to the first</param>
        /// <returns></returns>
        /// <remarks>V8.0.1.9 Allow to pass null and we will perform the check. This simplifies code for the caller.
        /// NEW IN v8.0.0.3</remarks>
        public static bool IsSameDictionary(Dictionary<string, string>? first, Dictionary<string, string>? second)
        {
            // if both are null then yes technically same list
            if (first == null && second == null) return true;

            // if only one is null then they are not
            if (first == null || second == null) return false;

            if (first.Count != second.Count) return false;

            foreach (string key in first.Keys)
            {
                if (second.ContainsKey(key) == false) return false;
                if (first[key] != second[key]) return false;
            }

            return true;
        }

        #endregion

        #region 030 List Validation

        /// <summary>
        /// If the first and second list are identical including order
        /// </summary>
        /// <param name="first">list of strings to compare</param>
        /// <param name="second">list of string to comare to the first</param>
        /// <returns></returns>
        /// <remarks>v8.0.1.9 allow nulls to be passed and w do the check
        /// NEW IN v8.0.0.3</remarks>
        public static bool IsSameList(List<string>? first, List<string>? second)
        {
            return IsSameList(first, second, false);
        }

        /// <summary>
        /// If the first and second list are identical including order
        /// </summary>
        /// <param name="first">string array to compare</param>
        /// <param name="second">string array to compare to the first</param>
        /// <param name="ignoreOrder">if true will sort both lists asc then do the match</param>
        /// <returns></returns>
        /// <remarks>v8.0.1.1 first and second parameters changed to string arrays</remarks>
        public static bool IsSameList(List<string>? first, List<string>? second, bool ignoreOrder)
        {
            // if both are null then yes technically same list
            if (first == null && second == null) return true;

            // if only one is null then they are not
            if (first == null || second == null) return false;

            if (first.Count != second.Count) return false;

            var firstAsc = ignoreOrder ? first.OrderBy(x => x).ToList() : first;
            var secondAsc = ignoreOrder ? second.OrderBy(x => x).ToList() : second;

            for (int index = 0; index < firstAsc.Count; index++)
            {
                if (firstAsc[index] != secondAsc[index]) return false;
            }

            return true;
        }

        #endregion

        #region 031 Array Validation 

        /// <summary>
        /// If the first and second list are identical including order
        /// </summary>
        /// <param name="first">list of strings to compare</param>
        /// <param name="second">list of string to comare to the first</param>
        /// <returns></returns>
        /// <remarks>v8.0.1.1 first and second parameters changed to string arrays
        /// NEW IN v8.0.0.3</remarks>
        public static bool IsSameArray(string[]? first, string[]? second)
        {
            return IsSameArray(first, second, false);
        }

        /// <summary>
        /// If the first and second array are identical including order
        /// </summary>
        /// <param name="first">string array to compare</param>
        /// <param name="second">string array to compare to the first</param>
        /// <param name="ignoreOrder">if true will sort both lists asc then do the match</param>
        /// <returns></returns>
        /// <remarks>v8.0.1.1 first and second parameters changed to string arrays</remarks>
        public static bool IsSameArray(string[]? first, string[]? second, bool ignoreOrder)
        {
            // if both are null then yes technically same list
            if (first == null && second == null) return true;

            // if only one is null then they are not
            if (first == null || second == null) return false;

            if (first.Length != second.Length) return false;

            var firstAsc = ignoreOrder ? first.OrderBy(x => x).ToArray() : first;
            var secondAsc = ignoreOrder ? second.OrderBy(x => x).ToArray(): second;

            for (int index = 0; index < firstAsc.Length; index++)
            {
                if (firstAsc[index] != secondAsc[index]) return false;
            }

            return true;
        }

        #endregion

        #region Array Manipulation

        /// <summary>
        /// Adds a string to the end of the array
        /// </summary>
        /// <param name="value">Value to add</param>
        /// <returns></returns>
        /// <remarks>NEW IN v8.0.1.4</remarks>
        public static string[] AddStringToArray(string []? stringArray, string value)
        {
            var stringList = stringArray == null ? new List<string>() : stringArray.ToList();
            stringList.Add(value);
            return stringList.ToArray();
        }

        /// <summary>
        /// Adds a string to the end of the array
        /// </summary>
        /// <param name="values">values to add</param>
        /// <returns></returns>
        /// <remarks>NEW IN v8.0.1.4</remarks>
        public static string[] AddStringsToArray(string[]? stringArray, string [] values)
        {
            if (stringArray == null) return values;

            var stringList = stringArray.ToList();
            foreach (var value in values)
            {
                stringList.Add(value);
            }
            return stringList.ToArray();
        }

        #endregion

        #region Id Related

        /// <summary>
        /// This will remove any special characters and replace all whitespace with underscore.
        /// </summary>
        /// <param name="possibleId"></param>
        public static string CalculateSafeId(string possibleId)
        {
            return ConvertToAlphaNumeric(possibleId.Trim().ToUpperInvariant(), false, false, true, true);
        }

        #endregion
    }
}
