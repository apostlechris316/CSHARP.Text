﻿/********************************************************************************
 * CSHARP Text Library - General utility to manipulate text strings
 * 
 * NOTE: Adapted from Clinch.Text
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 *          
 * CHANGES: 
 * 
 *  - (v5.0) All methods converted to static
 *  - (v5.0) Additional code to check parameters passed to exit method quicker
 *  - (v8.0) Upgraded to NET8.0 
 *  - v8.0.1.0 - Migrated from TemplateEngine. Remove dependency on Traits
 *
 *  POSSIBLE FUTURE IMPROVEMENTS
 *  
 *  -
 *  
 ********************************************************************************/

using System.Runtime.CompilerServices;
using System.Text;

namespace CSHARP.V8.Helpers.TextString
{
    /// <summary>
    /// static methods that assist with token parsing tasks
    /// </summary>
    public static class TokenHelperStatic
    {
        #region 001 - FindAllTokensInItem 

        /// <summary>
        /// Attempts to calculate the possible token wrappers in the template.
        /// Currently we look for {{ [[ { and [ but we could add more options for tokens later
        /// </summary>
        /// <param name="templateContents">The contents of the template</param>
        /// <returns></returns>
        /// <remarks>NEW IN 1.0.1.6</remarks>
        public static string CalculatePossibleTokenWrappers(string templateContents)
        {
            StringBuilder possibleTokens = new StringBuilder();
            string templateContentsToProcess = templateContents;

            if (templateContentsToProcess.Contains("{{"))
            {
                possibleTokens.Append("{{TOKEN}}");
                templateContentsToProcess = templateContentsToProcess.Replace("{{", string.Empty).Replace("}}", string.Empty);
            }

            if (templateContentsToProcess.Contains("[["))
            {
                if(possibleTokens.Length > 0)
                {
                    possibleTokens.Append(',');
                }
                possibleTokens.Append("[[TOKEN]]");
                templateContentsToProcess = templateContentsToProcess.Replace("[[", string.Empty).Replace("]]", string.Empty);
            }

            if (templateContentsToProcess.Contains("{"))
            {
                if (possibleTokens.Length > 0)
                {
                    possibleTokens.Append(',');
                }
                possibleTokens.Append("{TOKEN}");
                templateContentsToProcess = templateContentsToProcess.Replace("{", string.Empty).Replace("}", string.Empty);
            }

            if (templateContentsToProcess.Contains("["))
            {
                if (possibleTokens.Length > 0)
                {
                    possibleTokens.Append(',');
                }
                possibleTokens.Append("[TOKEN]");
                templateContentsToProcess = templateContentsToProcess.Replace("[", string.Empty).Replace("]", string.Empty);
            }

            return possibleTokens.ToString();
        }

        /// <summary>
        /// This method will scan the item for all tokens using the token wrappers templates
        /// </summary>
        /// <param name="tokenWrappers">These are a comma delimited sample token wrappers in the form "{start_token}TOKEN{end_token}" eg. [[TOKEN]] or {{TOKEN}} or [TOKEN] as examples</param>
        /// <param name="item">The item to get tokens from</param>
        /// <returns></returns>
        /// <remarks>v8.0.1.5 changed return value to a string array instead of a list</remarks>
        public static string[] FindAllTokensInItem(string tokenWrappers, string item)
        {
            if (string.IsNullOrWhiteSpace(tokenWrappers)) throw new ArgumentNullException(nameof(tokenWrappers));
            if (string.IsNullOrWhiteSpace(item)) throw new ArgumentNullException(nameof(item));

            return FindAllTokensInItem(tokenWrappers.Split(","), item);
        }

        /// <summary>
        /// This method separates the token wrappers into its start and end tokens.
        /// So if token wrapper was [[TOKEN]] it would return an array { '[[',']]' }
        /// </summary>
        /// <param name="tokenWrapper">This is a sample token wrapper in the form "{start_token}TOKEN{end_token}" eg. [[TOKEN]] or {{TOKEN}} or [TOKEN] as examples</param>
        /// <returns></returns>
        /// <exception cref="ArgumentException"></exception>
        /// <remarks>NEW IN v8.0.1.5</remarks>
        public static string[] GetTokenWrapperParts(string tokenWrapper)
        {
            if (string.IsNullOrWhiteSpace(tokenWrapper)) throw new ArgumentNullException(nameof(tokenWrapper));

            var possibleTokenParts = tokenWrapper.Split("TOKEN");
            if (possibleTokenParts.Length != 2)
            {
                throw new ArgumentException(paramName: nameof(tokenWrapper), message: "ERROR: the tokenWrapper (" + tokenWrapper + ") is invalid. It should have two parts around 'TOKEN'");
            }

            return possibleTokenParts.ToArray();
        }

        /// <summary>
        /// This method will scan the item for all tokens using the token wrappers templates
        /// </summary>
        /// <param name="tokenWrappers">These are a list of sample token wrappers in the form "{start_token}TOKEN{end_token}" eg. [[TOKEN]] or {{TOKEN}} or [TOKEN] as examples</param>
        /// <param name="item">The item to get tokens from</param>
        /// <returns></returns>
        /// <exception cref="ArgumentException"></exception>
        /// <remarks>v8.0.1.5 changed return value to a string array instead of a list</remarks>
        public static string[] FindAllTokensInItem( string [] tokenWrappers, string item)
        {
            if (0 == tokenWrappers.Length) throw new ArgumentNullException(nameof(tokenWrappers));
            if (string.IsNullOrWhiteSpace(item)) throw new ArgumentNullException(nameof(item));

            string itemToProcess = item;

            List<string> tokenList = new List<string>();
            foreach (var tokenWrapper in tokenWrappers)
            {
                bool didReplace = true;
                while (string.IsNullOrEmpty(itemToProcess) == false && didReplace == true)
                {
                    var possibleTokenParts = GetTokenWrapperParts(tokenWrapper);
                    if (possibleTokenParts.Length != 2)
                    {
                        throw new ArgumentException(paramName: nameof(tokenWrappers), message: "ERROR: the tokenWrapper (" + tokenWrapper + ") is invalid. It should have two parts around 'TOKEN'");
                    }

                    // If the token is actually in the string
                    if (itemToProcess.Contains(possibleTokenParts[0]) == false || itemToProcess.Contains(possibleTokenParts[1]) == false)
                    {
                        didReplace = false;
                        continue;
                    }

                    string foundToken = StringHelperStatic.DeleteBefore(itemToProcess, possibleTokenParts[0], true);
                    foundToken = StringHelperStatic.DeleteAfter(foundToken, possibleTokenParts[1], true);
                    tokenList.Add(foundToken);
                    itemToProcess = itemToProcess.Replace(foundToken, string.Empty);
                }
            }

            return tokenList.ToArray();
        }

        #endregion

        #region 002 - MergeTokens

        /// <summary>
        /// SmartTokens looks to see if the contextItem contains some special token options like :UPPER or :PROPER and 
        /// </summary>
        /// <param name="tokenWrapper">This is the wrapper of your token</param>
        /// <param name="contentItem"></param>
        /// <param name="tokens"></param>
        /// <returns></returns>
        public static string SmartMergeTokens(string tokenWrapper, string contentItem, Dictionary<string,string> tokens)
        {
            // IMPORTANT: We want them to do all their replacements first then we can apply our sial tokens.
            // This is needed as we support nested tokens
            Dictionary<string,string> smartTokens = new Dictionary<string, string>();

            // Create our special tokens
            foreach (var token in tokens)
            {
                if(string.IsNullOrEmpty(token.Value)) continue;

                var tokenWrapperParts = GetTokenWrapperParts(tokenWrapper);
                var actualTokenName = StringHelperStatic.GetAfter(StringHelperStatic.GetBefore(token.Key, tokenWrapperParts[1], false), tokenWrapperParts[0], false);
                if(actualTokenName.Contains(":"))
                {
                    actualTokenName = StringHelperStatic.GetBefore(actualTokenName, ":", false);
                }

                if (string.IsNullOrEmpty(actualTokenName)) continue;
                
                string newKey = string.Empty;
                string newValue = string.Empty;

                // Lower is simple
                if (contentItem.Contains(":LOWER") || token.Key.Contains(":LOWER"))
                {                    
                    newKey = tokenWrapperParts[0] + actualTokenName + ":LOWER" + tokenWrapperParts[1];
                    newValue = token.Value.ToLowerInvariant();

                    if (smartTokens.ContainsKey(newKey)) { smartTokens[newKey] = newValue; } else { smartTokens.Add(newKey, newValue); }
                }

                // Proper takes some work to do do capital on each word. This is a Quick and dirty way.
                if (contentItem.Contains(":PROPER") || token.Key.Contains(":PROPER"))
                {
                    newKey = tokenWrapperParts[0] + actualTokenName + ":PROPER" + tokenWrapperParts[1];

                    var words = StringHelperStatic.SplitStringIntoWords(token.Value);
                    newValue = token.Value;
                    foreach (var word in words)
                    {
                        newValue = newValue.Replace(word, word.Substring(0, 1).ToUpperInvariant() + word.Substring(1).ToLowerInvariant());
                    }

                    if (smartTokens.ContainsKey(newKey)) { smartTokens[newKey] = newValue; } else { smartTokens.Add(newKey, newValue); }
                }

                // Upper is easy
                if (contentItem.Contains(":UPPER"))
                {
                    newKey = tokenWrapperParts[0] + actualTokenName + ":UPPER" + tokenWrapperParts[1];
                    newValue = token.Value.ToUpperInvariant();
                    if (smartTokens.ContainsKey(newKey)) { smartTokens[newKey] = newValue; } else { smartTokens.Add(newKey, newValue); }
                }

                if (contentItem.Contains(":REMOVE_OUTER_QUOTES"))
                {
                    newKey = tokenWrapperParts[0] + actualTokenName + ":REMOVE_OUTER_QUOTES" + tokenWrapperParts[1];
                    newValue = StringHelperStatic.GetAfter(StringHelperStatic.GetBeforeLast(token.Value, "\"", false), "\"", false);

                    if (smartTokens.ContainsKey(newKey)) { smartTokens[newKey] = newValue; } else { smartTokens.Add(newKey, newValue); }
                }

                newKey = tokenWrapperParts[0] + actualTokenName + tokenWrapperParts[1];
                newValue = token.Value;
                if (smartTokens.ContainsKey(newKey)) { smartTokens[newKey] = newValue; } else { smartTokens.Add(newKey, newValue); }
            }

            return MergeTokens(contentItem, smartTokens);
        }

        /// <summary>
        /// This method will replace the tokens found in contentItem and return the results
        /// </summary>
        /// <param name="contentItem">Item to replace tokens in</param>
        /// <param name="tokens">Tokens to replace</param>
        /// <returns>Result of replacing the tokens in the content item</returns>
        /// <remarks>This version performs simple token replacement however derived classes may support additional functionality</remarks>
        public static string MergeTokens(string contentItem, Dictionary<string, string> tokens)
        {
            if (string.IsNullOrEmpty(contentItem)) throw new ArgumentNullException(paramName: nameof(contentItem), message: "ERROR: We can't replace items if have the " + nameof(contentItem));
            if (tokens == null || tokens.Count == 0) throw new ArgumentNullException(paramName: nameof(tokens), message: "ERROR: We can't replace items if have the " + nameof(tokens));

            string resultingContentItem = contentItem;
            bool replacedAToken = false;
            foreach (var token in tokens)
            {
                // TO DO: provide support for special tokens like current date and time.


                if (resultingContentItem.IndexOf(token.Key, StringComparison.OrdinalIgnoreCase) > -1) replacedAToken = true;
                
                resultingContentItem = resultingContentItem.Replace(token.Key, token.Value);
            }

            // if we replaced a token then possibly we have a nested token so call it again to see
            if (replacedAToken)
            {
                return MergeTokens(resultingContentItem, tokens);
            }

            return resultingContentItem;
        }

        #endregion

        #region 003 MergeTokensInFile

        /// <summary>
        /// This method will replace the tokens found in contentItem and return the results
        /// </summary>
        /// <param name="itemFileName">full path to item to replace tokens in</param>
        /// <param name="tokens">Tokens to replace</param>
        /// <returns>Result of replacing the tokens in the content item</returns>
        /// <remarks>This version performs simple token replacement however derived classes may support additional functionality</remarks>
        public static string[] MergeTokensInFile(string itemFileName, Dictionary<string, string> tokens)
        {
            string itemContents = File.ReadAllText(itemFileName);
            string result = MergeTokens(itemContents, tokens);

            string resultFilename = MergeTokens(itemFileName, tokens);

            // if contents or filenames are tokened
            if (itemContents != result || itemFileName != resultFilename)
            {
                // Backup the file and save the change
                File.Move(itemFileName, itemFileName + "_" + DateTime.Now.Year + "_" + DateTime.Now.Month + "_" + DateTime.Now.Day + "_" + DateTime.Now.Hour + "_" + DateTime.Now.Minute);

                File.WriteAllText(resultFilename, result);
            }

            // TO DO: For now we produce no results however we should place something regarding the replacements
            return new List<string>().ToArray();
        }

        #endregion

        #region 004 - MergeTokensInFiles 

        /// <summary>
        /// This method will replace the tokens found in all the files mathcing a given patter and return the results
        /// </summary>
        /// <param name="itemFileName">full path to item to replace tokens in</param>
        /// <param name="tokens">Tokens to replace</param>
        /// <returns>Result of replacing the tokens in the content item</returns>
        /// <remarks>This version performs simple token replacement however derived classes may support additional functionality</remarks>
        public static string[] MergeTokensInFiles(string itemFolder, string itemPattern, Dictionary<string, string> tokens)
        {
            foreach (var itemFilePath in Directory.GetFiles(itemFolder, itemPattern))
            {
                MergeTokensInFile(itemFilePath, tokens);
            }

            // TO DO: For now we produce no results however we should place something regarding the replacements
            return new List<string>().ToArray();
        }

        #endregion

        #region 005 - ReplaceAllTokensInTemplateContentWithAMarker

        /// <summary>
        /// Look in the template content for token wrappers and replace every token with the same marker. This is useful to see any errors in the template
        /// </summary>
        /// <param name="templateContents"></param>
        /// <param name="tokenWrappers"></param>
        public static string ReplaceAllTokensInTemplateContentWithAMarker(string templateContents, string tokenWrappers, string marker)
        {
            var tokens = TokenHelperStatic.FindAllTokensInItem(tokenWrappers, templateContents);
            var tokensToReplace = new Dictionary<string, string>();

            // BUILD THE REPLACE TO BE SOMETHING THAT IS NOT EXPECTED IN THE FILE BUT OBVIOUS TO SEE
            foreach (var token in tokens) { tokensToReplace.Add(token, marker); }
            return MergeTokens(templateContents, tokensToReplace);
        }

        #endregion 

        #region 006 - ValidateAllTemplates

        /// <summary>
        /// Opens the templates in the specified folder and replaces the values with token markers so we can compare with results
        /// </summary>
        /// <param name="templateFolder">the folder containing the templates</param>
        /// <param name="destinationTemplateFolder">the folder to store the temporary template files</param>
        /// <param name="expectedResultsTemplateFolder">the folder containing the results to compare with</param>
        public static string[] ValidateAllTemplates(string tokenWrappers, string templateFolder, string destinationTemplateFolder, string expectedResultsTemplateFolder)
        {
            if (string.IsNullOrEmpty(tokenWrappers)) throw new ArgumentNullException(nameof(tokenWrappers));
            if (string.IsNullOrEmpty(templateFolder)) throw new ArgumentNullException(nameof(templateFolder));
            if (string.IsNullOrEmpty(destinationTemplateFolder)) throw new ArgumentNullException(nameof(destinationTemplateFolder));
            if (string.IsNullOrEmpty(expectedResultsTemplateFolder)) throw new ArgumentNullException(nameof(expectedResultsTemplateFolder));

            if (Directory.Exists(templateFolder) == false) throw new DirectoryNotFoundException(nameof(templateFolder));
            if (Directory.Exists(destinationTemplateFolder) == false) throw new DirectoryNotFoundException(nameof(destinationTemplateFolder));
            if (Directory.Exists(expectedResultsTemplateFolder) == false) throw new DirectoryNotFoundException(nameof(expectedResultsTemplateFolder));

            return ValidateAllTemplates(tokenWrappers.Split(",").ToList(), templateFolder, destinationTemplateFolder, expectedResultsTemplateFolder);
        }

        /// <summary>
        /// Opens the templates in the specified folder and replaces the values with token markers so we can compare with results
        /// </summary>
        /// <param name="templateFolder">the folder containing the templates</param>
        /// <param name="destinationTemplateFolder">the folder to store the temporary template files</param>
        /// <param name="expectedResultsTemplateFolder">the folder containing the results to compare with</param>
        public static string[] ValidateAllTemplates(List<string> tokenWrappers, string templateFolder, string destinationTemplateFolder, string expectedResultsTemplateFolder)
        {
            var results = new List<string>();

            if(tokenWrappers == null || tokenWrappers.Count == 0) throw new ArgumentNullException(nameof(tokenWrappers));
            if (string.IsNullOrEmpty(templateFolder)) throw new ArgumentNullException(nameof(templateFolder));
            if (string.IsNullOrEmpty(destinationTemplateFolder)) throw new ArgumentNullException(nameof(destinationTemplateFolder));
            if (string.IsNullOrEmpty(expectedResultsTemplateFolder)) throw new ArgumentNullException(nameof(expectedResultsTemplateFolder));

            if (Directory.Exists(templateFolder) == false) throw new DirectoryNotFoundException(nameof(templateFolder));
            if (Directory.Exists(destinationTemplateFolder) == false) throw new DirectoryNotFoundException(nameof(destinationTemplateFolder));
            if (Directory.Exists(expectedResultsTemplateFolder) == false) throw new DirectoryNotFoundException(nameof(expectedResultsTemplateFolder));

            foreach (var templateFilePath in Directory.GetFiles(templateFolder, "*.json"))
            {
                // Get the template contents
                string templateContents = File.ReadAllText(templateFilePath);

                // Replace all tokens with the marker
                templateContents = ReplaceAllTokensInTemplateContentWithAMarker(templateContents, "[[TOKEN]]", "~~~~~~~~~~~");

                // SAVE THE RESULTS
                string destinationFilePath = templateFilePath.Replace(templateFolder, destinationTemplateFolder);
                File.WriteAllText(destinationFilePath, templateContents);

                // COMPARE WITH EXPECTED RESULTS (If the file exists in expected results)
                string expectedFilePath = templateFilePath.Replace(templateFolder, expectedResultsTemplateFolder);
                if (File.Exists(expectedFilePath))
                {
                    string expectedResults = File.ReadAllText(expectedFilePath);
                    if (expectedResults != templateContents) results.Add("ResultType = ERROR,Result = \"Result does not match expected result in: " + expectedFilePath + "\"");
                }
            }

            return results.ToArray();
        }

        #endregion

        #region 007 CheckPropertyValue 

        /// <summary>
        /// Checks Id to ensure template and item match.
        /// </summary>
        /// <param name="tokenWrappers">These are the possible tokens in the property eg. [[TOKEN]]</param>
        /// <param name="templateValue">The value in the template</param>
        /// <param name="itemValue">The value in the item</param>
        /// <param name="newItemValue">The suggested new value</param>
        /// <returns>True if the ids align or false if they don't.</returns>
        public static bool CheckPropertyValue(string tokenWrappers, string templateValue, string itemValue, out string newItemValue)
        {
            bool returnValue = true;
            newItemValue = string.Empty;

            var tokens = TokenHelperStatic.FindAllTokensInItem(tokenWrappers, templateValue);
            string tokenContentsToProcess = templateValue;
            string itemContentsToProcess = itemValue;

            bool autoCorrectMade = false;
            foreach (var token in tokens)
            {
                string beforeTokenInTemplate = StringHelperStatic.GetBefore(tokenContentsToProcess, token);

                if (itemContentsToProcess.StartsWith(beforeTokenInTemplate) == false)
                {
                    returnValue = false;

                    // CHECK 1: If the item has more around the id than the template
                    // Look at start of id and see the first few characters existin template id
                    string prefix = templateValue.Substring(0, 8);
                    if (itemValue.Contains(prefix))
                    {
                        string possibleNewValue = StringHelperStatic.GetAfter(itemValue, prefix, true);
                        newItemValue = possibleNewValue;
                        autoCorrectMade = true;
                        break;
                    }
                    // CHECK 2: If the template has more around the id than the item
                    // TO DO: It is likely the template has more than the item
                    else
                    {
                    }

                    // We know it doesn't match so go to next field
                    break;
                }

                // TO DO: We will assume there is one token in the string
                break;
            }

            return returnValue;
        }

        #endregion
    }
}
