/********************************************************************************
 * CSHARP Text Library - General utility to manipulate text strings
 * 
 * NOTE: Adapted from Clinch.Text
 * 
 * LICENSE: Free to use provided details on fixes and/or extensions emailed to 
 *          chris.williams@readwatchcreate.com
 *          
 * CHANGES: 
 * 
 *  - (v5.0) All methods converted to static
 *  - (v5.0) Additional code to check parameters passed to exit method quicker
 *  - (v8.0) Upgraded to NET8.0 
 *  
 *  POSSIBLE FUTURE IMPROVEMENTS
 *  
 *  -
 *  
 ********************************************************************************/

namespace CSHARP.V8.Helpers.TextString
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    /// Assists in cleaning up csv strings
    /// </summary>
    /// <remarks>
    ///	NEW IN v5.0.0.0
    /// </remarks>
    public static class CsvStringHelperStatic
	{
		/// <summary>
		/// Returns true if string passed in matches the Base64 RegEx
		/// </summary>
		/// <param name="stringBase64">possible base64 encoded string</param>
		/// <returns></returns>
		/// <remarks>v8.0.1.1 internally converted lists to arrays for better performance
		/// v5.0.0.0 Check if parameter is empty</remarks>
		public static string ConvertSpecificSpecificColumnsToAlphaNumericWithUnderscoreForSpaces(string csvString, string nameOfColumnsToProcess)
        {
			if (string.IsNullOrEmpty(csvString)) throw new ArgumentNullException(nameof(csvString));
			if (string.IsNullOrEmpty(nameOfColumnsToProcess)) throw new ArgumentNullException(nameof(nameOfColumnsToProcess));

			// First we divide the string into lines
			var lines = StringHelperStatic.SplitStringOnEndOfLine(csvString);

			// if single line then we are just doing validation of header vs columns to process as there is no data to fix
			if(lines.Length == 1)
            {
				string[]? headerParts = StringHelperStatic.DelimitedStringToStringArray(lines[0].ToUpperInvariant(), ',');
				if(headerParts == null) throw new ArgumentNullException(nameof(headerParts));

				var columnsToProcessArray = StringHelperStatic.DelimitedStringToStringArray(nameOfColumnsToProcess.ToUpperInvariant(), ',');
                if (columnsToProcessArray == null)
                    throw new ArgumentException(paramName: nameof(nameOfColumnsToProcess), message: "ERROR: could not parse into array");

                foreach (string columnName in columnsToProcessArray)
                {
					if(headerParts.Contains(columnName) == false) 
						throw new ArgumentException(paramName: nameof(nameOfColumnsToProcess), message: "ERROR: " + columnName + " does not exist in the header");
				}

				return csvString;
            }

			List<string> fixedLines = new List<string>();

			// Next we divide the column names passed in into a list
			string[]? columnNameList = StringHelperStatic.DelimitedStringToStringArray(nameOfColumnsToProcess, ',');
			if (columnNameList == null) throw new ArgumentException(nameOfColumnsToProcess);

			Dictionary<string, int> headerColumnMap = new Dictionary<string, int>();

			bool processingHeader = true;
			foreach (string line in lines)
			{
				// we will not process blank lines simply return as is
				if (string.IsNullOrEmpty(line) == true)
				{
					fixedLines.Add(line);
					continue;
				}

				// split the line so we can process it
				string[]? lineParts = StringHelperStatic.DelimitedStringToStringArray(line, ',');
				if (lineParts == null) throw new ArgumentException(nameof(csvString));

				// We assume the first line is the header
				if (processingHeader)
				{
					for (int partIndex = 0; partIndex < lineParts.Count(); partIndex++)
					{
						headerColumnMap.Add(lineParts[partIndex].ToUpperInvariant(), partIndex);
					}
					fixedLines.Add(line);
					processingHeader = false;
				}
				else
				{
					// Next we clean up the colums in the current line
					foreach (string column in columnNameList)
					{
						if (headerColumnMap.ContainsKey(column.ToUpperInvariant()) == false)
						{
							throw new ArgumentException(paramName: nameof(nameOfColumnsToProcess), message: "ERROR: " + column + " does not exist in the header");
						}

						lineParts[headerColumnMap[column.ToUpperInvariant()]] = StringHelperStatic.ConvertToAlphaNumeric(lineParts[headerColumnMap[column.ToUpperInvariant()]], false, false, true, true);
					}
					fixedLines.Add(StringHelperStatic.StringArrayToDelimitedString(lineParts, ","));
				}
			}

			return StringHelperStatic.StringArrayToEndOfLineDelimited(fixedLines.ToArray());
        }
	}
}
